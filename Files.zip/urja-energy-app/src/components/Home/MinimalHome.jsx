import React from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Zap, 
  Activity, 
  TrendingUp, 
  Clock, 
  Sun, 
  ArrowRight, 
  Sparkles, 
  Sliders, 
  Leaf, 
  Coins, 
  Calculator, 
  Compass, 
  ChevronRight,
  Menu,
  ShieldCheck
} from 'lucide-react';

export const MinimalHome = () => {
  const { 
    userProfile, 
    regionConfig, 
    setActiveView, 
    setIsNavPanelOpen,
    vampireCalculations, 
    retrofitCalculations, 
    loadShiftCalculations, 
    solarCalculations,
    ecoScore,
    inventory
  } = useEnergy();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      
      {/* Top Floating Status Pill & 3-Line Panel Quick Trigger */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-urja-navy-800/90 text-slate-300 border border-urja-cyan-400/30 text-xs font-semibold shadow-glow-cyan">
          <span className="w-2 h-2 rounded-full bg-urja-lime-400 animate-pulse"></span>
          <span className="text-white font-bold">{regionConfig?.discom?.split('(')[0] || 'DISCOM Grid'}</span>
          <span className="text-urja-navy-600">•</span>
          <span>Base Rate: <strong className="text-urja-cyan-300">₹{regionConfig?.baseTariff || '7.20'}/kWh</strong></span>
          <span className="text-urja-navy-600">•</span>
          <span className="text-rose-400 font-bold">{vampireCalculations?.currentVampireWatts || 138}W Standby Floor</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-urja-navy-800 border border-urja-lime-500/40 text-urja-lime-400 hover:bg-urja-navy-750 text-xs font-bold transition-all shadow-glow-lime active:scale-95"
          >
            <Menu className="w-3.5 h-3.5" />
            <span>Open 3-Line Studio Panel</span>
          </button>

          <button
            onClick={() => setActiveView('setup')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-urja-cyan-400" />
            <span>{userProfile?.homeType || '3BHK'} Config</span>
            <ChevronRight className="w-3 h-3 text-slate-500" />
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-urja-lime-500/10 text-urja-lime-400 border border-urja-lime-500/30 text-xs font-extrabold uppercase tracking-widest shadow-glow-lime">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Sanskrit: ऊर्जा — The Force of Life & Clean Energy</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-tight">
          Power Tomorrow.{' '}
          <span className="text-gradient-urja block sm:inline">
            Smarter Today.
          </span>
        </h1>
        
        <p className="text-base sm:text-lg text-slate-400 font-medium max-w-2xl mx-auto">
          Our mission is to make energy <span className="text-white font-bold">smarter, cleaner, and more accessible</span> for every household. Calibrated for your {inventory?.airConditioners?.length || 2} ACs and appliances in {userProfile?.city?.split(',')[0] || 'your city'}.
        </p>

        {/* 3 High-Impact Live Metrics */}
        <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          
          <div className="cyber-card rounded-2xl p-4 shadow-cyber">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Continuous Vampire Loss</span>
              <Activity className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-black text-rose-400">
              ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()}
              <span className="text-xs font-normal text-slate-400 ml-1">/mo</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              ~{vampireCalculations?.monthlyWastedKwh || 110} units leaked 24/7 on standby
            </div>
          </div>

          <div className="cyber-card rounded-2xl p-4 shadow-cyber">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Unlockable Via Upgrades</span>
              <TrendingUp className="w-4 h-4 text-urja-lime-400" />
            </div>
            <div className="text-2xl font-black text-urja-lime-400">
              ₹{((retrofitCalculations?.monthlyMoneySaved || 1850) + (loadShiftCalculations?.monthlySavingsRupees || 620)).toLocaleString()}
              <span className="text-xs font-normal text-slate-400 ml-1">/mo</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              ₹{(((retrofitCalculations?.annualMoneySaved || 22000) + (loadShiftCalculations?.annualSavingsRupees || 7400))).toLocaleString()} yearly wealth unlocked
            </div>
          </div>

          <div className="cyber-card rounded-2xl p-4 shadow-cyber">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>PM Surya Ghar Subsidy</span>
              <Sun className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-400">
              ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()}
              <span className="text-xs font-normal text-slate-400 ml-1">Grant</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              For {solarCalculations?.recommendedCapacityKw || 3} kW system auto-matched
            </div>
          </div>

        </div>
      </div>

      {/* The 4 Core Pillars Section (Minimal Modern Cards with "More Info" Navigation) */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              The 4 Core Energy Pillars
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Click <strong className="text-urja-lime-400 font-bold">"More Info"</strong> on any pillar to launch its dedicated deep-dive studio.
            </p>
          </div>
          <button
            onClick={() => setActiveView('dashboard')}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-urja-navy-800 hover:bg-urja-navy-750 text-urja-cyan-300 border border-urja-cyan-400/40 transition-all shadow-glow-cyan"
          >
            <span>Executive Dashboard View</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* PILLAR 1: Vampire Load & Appliance Health Diagnostics */}
          <div className="cyber-card rounded-3xl p-6 sm:p-7 shadow-cyber relative overflow-hidden flex flex-col justify-between group">
            <div className="absolute top-0 right-0 w-36 h-36 bg-rose-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-rose-500/20 transition-all"></div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full bg-rose-950/60 text-rose-300 border border-rose-800/60">
                  Pillar 1 • Diagnostics
                </span>
                <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  {vampireCalculations?.currentVampireWatts || 138}W Baseline
                </span>
              </div>

              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-rose-400" />
                <span>"Vampire Load" & Appliance Diagnostics</span>
              </h3>
              
              <p className="mt-2 text-xs sm:text-sm text-slate-400 leading-relaxed">
                AI pattern-matching detects continuous phantom loads and failing compressor cycle spikes quietly draining ₹{(vampireCalculations?.annualFinancialWaste || 9360).toLocaleString()} every single year.
              </p>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Monthly Loss</div>
                  <div className="text-base font-extrabold text-rose-400">
                    ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()} / mo
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Appliance Anomaly</div>
                  <div className="text-base font-extrabold text-amber-400">
                    1 Refrigerator Seal Alert
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-urja-navy-750 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Smart relay isolation controls
              </span>
              <button
                onClick={() => setActiveView('vampire')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-600/30 transition-all hover:scale-105 active:scale-95"
              >
                <span>More Info</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* PILLAR 2: Dynamic Retrofit ROI Simulator */}
          <div className="cyber-card rounded-3xl p-6 sm:p-7 shadow-cyber relative overflow-hidden flex flex-col justify-between group">
            <div className="absolute top-0 right-0 w-36 h-36 bg-urja-lime-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-urja-lime-500/20 transition-all"></div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full bg-urja-lime-500/20 text-urja-lime-300 border border-urja-lime-500/40">
                  Pillar 2 • Retrofit
                </span>
                <span className="text-xs font-bold text-urja-lime-400 flex items-center gap-1">
                  <Leaf className="w-3.5 h-3.5" />
                  {retrofitCalculations?.co2TonnesPerYear || '2.4'} T CO₂/yr Saved
                </span>
              </div>

              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-urja-lime-400" />
                <span>Dynamic "Retrofit ROI" Simulator</span>
              </h3>
              
              <p className="mt-2 text-xs sm:text-sm text-slate-400 leading-relaxed">
                Interactive payback model testing 5-Star Inverter ACs, 28W BLDC Fans, and Smart LEDs calibrated for your {inventory?.fansCount || 6} fans and {inventory?.airConditioners?.length || 2} ACs.
              </p>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Annual Savings</div>
                  <div className="text-base font-extrabold text-urja-lime-400">
                    ₹{(retrofitCalculations?.annualMoneySaved || 22000).toLocaleString()} / yr
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Payback Period</div>
                  <div className="text-base font-extrabold text-white">
                    {retrofitCalculations?.paybackYears || '2.1'} Years
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-urja-navy-750 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                10-Yr Wealth: ₹{(retrofitCalculations?.tenYearNetReturn || 85000).toLocaleString()}
              </span>
              <button
                onClick={() => setActiveView('retrofit')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all hover:scale-105 active:scale-95"
              >
                <span>More Info</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* PILLAR 3: Smart Tier & Peak-Hour Load Shifting */}
          <div className="cyber-card rounded-3xl p-6 sm:p-7 shadow-cyber relative overflow-hidden flex flex-col justify-between group">
            <div className="absolute top-0 right-0 w-36 h-36 bg-urja-cyan-400/10 rounded-full blur-3xl pointer-events-none group-hover:bg-urja-cyan-400/20 transition-all"></div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full bg-urja-cyan-400/20 text-urja-cyan-300 border border-urja-cyan-400/40">
                  Pillar 3 • Grid Sync
                </span>
                <span className="text-xs font-bold text-urja-cyan-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Peak: ₹{regionConfig?.peakTariff || '11.50'}/kWh
                </span>
              </div>

              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-urja-cyan-400" />
                <span>Smart Tier & Peak-Hour Load Shifting</span>
              </h3>
              
              <p className="mt-2 text-xs sm:text-sm text-slate-400 leading-relaxed">
                Automated tariff scheduler that moves heavy loads (geysers, EV charging, laundry) into green solar windows (10 AM - 3 PM) to avoid surge tariffs.
              </p>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Shifted Savings</div>
                  <div className="text-base font-extrabold text-urja-cyan-300">
                    ₹{(loadShiftCalculations?.monthlySavingsRupees || 620).toLocaleString()} / mo
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Surge Avoidance</div>
                  <div className="text-base font-extrabold text-white">
                    {loadShiftCalculations?.shiftedPercentage || 60}% Shifted
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-urja-navy-750 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Differential: ₹{loadShiftCalculations?.tariffDiff || '6.90'}/unit
              </span>
              <button
                onClick={() => setActiveView('loadshift')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold bg-urja-cyan-400 hover:bg-urja-cyan-300 text-urja-navy-950 shadow-glow-cyan transition-all hover:scale-105 active:scale-95"
              >
                <span>More Info</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* PILLAR 4: Urja-Mitra Solar & Subsidy Auto-Matcher */}
          <div className="cyber-card rounded-3xl p-6 sm:p-7 shadow-cyber relative overflow-hidden flex flex-col justify-between group">
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-400/10 rounded-full blur-3xl pointer-events-none group-hover:bg-amber-400/20 transition-all"></div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
                  Pillar 4 • Solar
                </span>
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                  <Sun className="w-3.5 h-3.5" />
                  PM Surya Ghar Scheme
                </span>
              </div>

              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Sun className="w-5 h-5 text-amber-400" />
                <span>"Urja-Mitra" Solar & Subsidy Matcher</span>
              </h3>
              
              <p className="mt-2 text-xs sm:text-sm text-slate-400 leading-relaxed">
                Calculates ideal rooftop capacity, guarantees ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()} in direct subsidies, and proves monthly loan EMI is lower than current bill!
              </p>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Ideal Capacity</div>
                  <div className="text-base font-extrabold text-amber-400">
                    {solarCalculations?.recommendedCapacityKw || 3} kW System
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-700">
                  <div className="text-[11px] text-slate-400">Net Investment</div>
                  <div className="text-base font-extrabold text-white">
                    ₹{(solarCalculations?.netCost || 96000).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-urja-navy-750 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Payback: {solarCalculations?.paybackYears || '2.8'} Yrs • Positive Cashflow
              </span>
              <button
                onClick={() => setActiveView('solar')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold bg-amber-500 hover:bg-amber-400 text-urja-navy-950 shadow-md shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
              >
                <span>More Info</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Futuristic Interactive Tools Banner */}
      <div className="cyber-card rounded-3xl p-6 sm:p-8 shadow-cyber flex flex-col sm:flex-row items-center justify-between gap-6 border-urja-lime-500/30">
        <div className="space-y-1 text-center sm:text-left">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-urja-lime-500/20 text-urja-lime-300 text-xs font-bold">
            <Calculator className="w-3.5 h-3.5" />
            <span>Interactive Calculators & Clean Tech</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Need an Instant Appliance Electricity Bill Calculation?
          </h3>
          <p className="text-xs text-slate-400 max-w-lg">
            Use our interactive Wattage & Hours calculator to compute your exact unit consumption and discover renewable alternatives.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setActiveView('calculator')}
            className="px-5 py-2.5 rounded-2xl text-xs font-extrabold bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all hover:scale-105"
          >
            Launch Electricity Calculator
          </button>
          <button
            onClick={() => setActiveView('renewables')}
            className="px-5 py-2.5 rounded-2xl text-xs font-extrabold bg-urja-navy-800 hover:bg-urja-navy-750 text-urja-cyan-300 border border-urja-cyan-400/40 transition-all shadow-glow-cyan"
          >
            Renewable Explorer
          </button>
        </div>
      </div>

    </div>
  );
};
