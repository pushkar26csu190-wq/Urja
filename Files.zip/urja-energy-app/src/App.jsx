import React, { Component } from 'react';
import { EnergyProvider, useEnergy } from './context/EnergyContext';
import { Navbar } from './components/Common/Navbar';
import { ThreeLineNavPanel } from './components/Common/ThreeLineNavPanel';
import { NotificationDrawer } from './components/Common/NotificationDrawer';
import { MinimalHome } from './components/Home/MinimalHome';
import { SetupWizard } from './components/Onboarding/SetupWizard';
import { LoginScreen } from './components/Onboarding/LoginScreen';
import { DashboardOverview } from './components/Dashboard/DashboardOverview';
import { VampireLoadDiagnostics } from './components/Pillars/VampireLoadDiagnostics';
import { RetrofitSimulator } from './components/Pillars/RetrofitSimulator';
import { PeakHourLoadShifting } from './components/Pillars/PeakHourLoadShifting';
import { UrjaMitraSolar } from './components/Pillars/UrjaMitraSolar';
import { CommunityLeaderboard } from './components/Community/CommunityLeaderboard';
import { ElectricityCalculator } from './components/Tools/ElectricityCalculator';
import { RenewableExplorer } from './components/Tools/RenewableExplorer';
import { Zap, AlertTriangle, RefreshCw } from 'lucide-react';

// Robust React Error Boundary
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("URJA Platform caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[70vh] flex items-center justify-center p-6 text-center">
          <div className="max-w-md w-full cyber-card rounded-3xl p-8 border-rose-500/40 shadow-cyber space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/30 mx-auto flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-black text-white">Temporary Engine Recalibration</h2>
            <p className="text-xs text-slate-400">
              URJA AI encountered an unexpected calculation state. Click below to reset to a healthy baseline.
            </p>
            <button
              onClick={() => {
                this.setState({ hasError: false });
                window.location.reload();
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black bg-urja-lime-500 text-urja-navy-950 shadow-glow-lime hover:bg-urja-lime-400 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reload Baseline Engine</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const AppContent = () => {
  const { activeView, setActiveView, theme } = useEnergy();

  return (
    <div className={`min-h-screen flex flex-col ${theme === 'light' ? 'bg-[#F8FAFC] text-slate-900' : 'bg-[#07111F] text-slate-200'} transition-colors duration-300 energy-grid selection:bg-urja-lime-500 selection:text-urja-navy-950 overflow-x-hidden w-full max-w-full`}>
      <Navbar />
      <ThreeLineNavPanel />
      <NotificationDrawer />

      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        <ErrorBoundary>
          {activeView === 'login' && <LoginScreen />}
          {activeView === 'setup' && <SetupWizard />}
          {activeView === 'home' && <MinimalHome />}
          {activeView === 'dashboard' && <DashboardOverview />}
          {activeView === 'calculator' && <ElectricityCalculator />}
          {activeView === 'renewables' && <RenewableExplorer />}
          {activeView === 'vampire' && <VampireLoadDiagnostics />}
          {activeView === 'retrofit' && <RetrofitSimulator />}
          {activeView === 'loadshift' && <PeakHourLoadShifting />}
          {activeView === 'solar' && <UrjaMitraSolar />}
          {activeView === 'community' && <CommunityLeaderboard />}
        </ErrorBoundary>
      </main>

      {/* Footer */}
      <footer className="border-t border-urja-navy-750 py-8 bg-urja-navy-950/70 backdrop-blur-md text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-urja-lime-500 to-urja-cyan-400 flex items-center justify-center text-urja-navy-950 font-black shadow-glow-lime">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div>
              <span className="font-black tracking-wide">URJA (ऊर्जा)</span>
              <span className="text-slate-500 mx-2">•</span>
              <span className="text-urja-lime-400 font-semibold">Power Tomorrow. Smarter Today.</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button 
              onClick={() => setActiveView('setup')}
              className="hover:text-urja-cyan-300 transition-colors"
            >
              Appliance Setup Wizard
            </button>
            <span className="text-slate-600">•</span>
            <button 
              onClick={() => setActiveView('calculator')}
              className="hover:text-urja-lime-400 transition-colors"
            >
              Electricity Calculator
            </button>
            <span className="text-slate-600">•</span>
            <button 
              onClick={() => setActiveView('renewables')}
              className="hover:text-urja-cyan-300 transition-colors"
            >
              Renewables Explorer
            </button>
            <span className="text-slate-600">•</span>
            <span className="text-slate-500">Student Innovation Hackathon</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <EnergyProvider>
      <AppContent />
    </EnergyProvider>
  );
}
