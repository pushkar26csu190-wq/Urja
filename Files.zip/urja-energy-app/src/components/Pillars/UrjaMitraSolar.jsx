import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Sun, 
  Sparkles, 
  ArrowLeft, 
  CheckCircle2, 
  DollarSign, 
  Zap, 
  Menu
} from 'lucide-react';

export const UrjaMitraSolar = () => {
  const { 
    solarCalculations, 
    userProfile, 
    regionConfig, 
    setActiveView,
    setIsNavPanelOpen,
    triggerConfetti 
  } = useEnergy();

  const [applied, setApplied] = useState(false);

  const handleApplySubsidy = () => {
    setApplied(true);
    triggerConfetti();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-amber-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 shadow-md">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/40">
                  Pillar 4
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  "Urja-Mitra" Solar & Subsidy Auto-Matcher
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Automated matching for PM Surya Ghar Muft Bijli Yojana & {regionConfig?.state || 'State'} Solar incentives.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white"
            title="3-Line Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          <button
            onClick={handleApplySubsidy}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-urja-navy-950 shadow-md shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>{applied ? '✓ Feasibility Application Logged' : 'Auto-Match PM Surya Ghar Subsidy'}</span>
          </button>
        </div>
      </div>

      {/* Applied Banner */}
      {applied && (
        <div className="p-4 rounded-2xl bg-urja-lime-500/10 border border-urja-lime-500/40 text-urja-lime-300 flex items-center justify-between shadow-glow-lime">
          <div className="flex items-center gap-3 text-xs">
            <CheckCircle2 className="w-5 h-5 text-urja-lime-400 shrink-0" />
            <div>
              <span className="font-bold text-white">Application Pre-Filled for {userProfile?.name}!</span>
              <p className="text-[11px] text-slate-300">
                DISCOM: {regionConfig?.discom} • Consumer ID: URJA-SOLAR-784 • Grant of ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()} matched.
              </p>
            </div>
          </div>
          <span className="text-xs font-black px-3 py-1 bg-urja-lime-500 text-urja-navy-950 rounded-lg">
            Ready for Inspection
          </span>
        </div>
      )}

      {/* 4 Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Recommended Solar Size</div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400">
            {solarCalculations?.recommendedCapacityKw || 3}
            <span className="text-sm font-semibold text-slate-400 ml-1">kWp</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Requires {solarCalculations?.requiredRoofSqFt || 285} sq. ft. shadow-free roof
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Total Govt Subsidy</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-lime-400">
            ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()}
          </div>
          <div className="text-[11px] text-urja-lime-400 mt-1 font-semibold">
            ₹{(solarCalculations?.centralSubsidy || 78000).toLocaleString()} PM Surya Ghar + ₹{(solarCalculations?.stateSubsidy || 12000).toLocaleString()} State
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Net Out-Of-Pocket</div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            ₹{(solarCalculations?.netCost || 96000).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Payback in merely {solarCalculations?.paybackYears || '2.8'} years
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">25-Year Wealth Created</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-cyan-300">
            ₹{((solarCalculations?.lifetimeSavings25Years || 1400000) / 100000).toFixed(1)}
            <span className="text-sm font-semibold text-slate-400 ml-1">Lakhs</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            25-year panel warranty
          </div>
        </div>

      </div>

      {/* Waterfall & EMI Surplus */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Waterfall */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-urja-lime-400" />
            <span>PM Surya Ghar Subsidy Waterfall Breakdown</span>
          </h3>
          <p className="text-xs text-slate-400">
            Government grants are directly credited to your bank account after net-meter commissioning.
          </p>

          <div className="space-y-3 pt-2 text-xs">
            <div className="p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-750 flex items-center justify-between">
              <div>
                <div className="font-bold text-white">Gross Benchmark Turnkey Cost</div>
                <div className="text-[10px] text-slate-400">Tier-1 Panels + Grid Inverter + Net Metering</div>
              </div>
              <div className="font-extrabold text-sm text-white">
                ₹{(solarCalculations?.grossCost || 174000).toLocaleString()}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-urja-lime-500/10 border border-urja-lime-500/30 flex items-center justify-between text-urja-lime-300">
              <div>
                <div className="font-bold">Less: PM Surya Ghar Central Subsidy</div>
                <div className="text-[10px] text-slate-400">Direct National Portal Transfer (DBT)</div>
              </div>
              <div className="font-black text-sm text-urja-lime-400">
                - ₹{(solarCalculations?.centralSubsidy || 78000).toLocaleString()}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-between text-urja-cyan-300">
              <div>
                <div className="font-bold">Less: {regionConfig?.state || 'State'} Incentive</div>
                <div className="text-[10px] text-slate-400">State renewable energy development grant</div>
              </div>
              <div className="font-black text-sm text-urja-cyan-300">
                - ₹{(solarCalculations?.stateSubsidy || 12000).toLocaleString()}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-urja-navy-800 border border-urja-lime-500/40 text-white flex items-center justify-between font-bold">
              <div>
                <div className="text-sm">Final Net Out-of-Pocket Investment</div>
                <div className="text-[10px] text-slate-400 font-normal">Actual capital required</div>
              </div>
              <div className="text-xl font-black text-urja-lime-400">
                ₹{(solarCalculations?.netCost || 96000).toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* 0-Down Loan vs Electricity Bill */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>0-Down Solar Loan: Immediate Monthly Profit</span>
          </h3>
          <p className="text-xs text-slate-400">
            Why pay the power company when your monthly solar EMI is lower than your current electricity bill?
          </p>

          <div className="space-y-3 pt-2">
            <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/30 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-rose-300">Current Monthly Power Bill</div>
                <div className="text-[11px] text-slate-400">Paid to {regionConfig?.discom?.split('(')[0] || 'DISCOM'} every month forever</div>
              </div>
              <div className="text-lg font-black text-rose-400">
                ₹{(userProfile?.monthlyBill || 6200).toLocaleString()} / mo
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-urja-navy-900 border border-urja-navy-750 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Solar 5-Year Concessional EMI</div>
                <div className="text-[11px] text-slate-400">PM Surya Ghar bank tie-up @ 7.0% per annum</div>
              </div>
              <div className="text-lg font-black text-urja-cyan-300">
                ₹{(solarCalculations?.monthlyLoanEmi || 1900).toLocaleString()} / mo
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-r from-urja-lime-500 to-urja-cyan-400 text-urja-navy-950 flex items-center justify-between font-bold shadow-glow-lime">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-urja-navy-900">
                  Instant Positive Monthly Cashflow
                </div>
                <div className="text-[11px] text-urja-navy-800">
                  Net surplus pocketed starting Month 1!
                </div>
              </div>
              <div className="text-2xl font-black">
                +₹{(solarCalculations?.instantMonthlyCashflow || 1800).toLocaleString()} / mo
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
