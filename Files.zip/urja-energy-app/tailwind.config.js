/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        urja: {
          navy: {
            950: '#040B15',
            900: '#07111F', // Brand Deep Navy
            850: '#0A1728',
            800: '#0D1C2E', // Surface Card
            750: '#112338',
            700: '#162E48', // Card Border
            600: '#1D3B5C',
          },
          lime: {
            400: '#C8F76F',
            500: '#B7F34A', // Brand Electric Lime
            600: '#9FE628',
            700: '#85C718',
          },
          cyan: {
            300: '#67D7FF',
            400: '#35C9FF', // Brand Cyan
            500: '#12B8F5',
            600: '#029BD4',
          },
          // Soft day modes if toggled
          mint: {
            50: '#F0FDF4',
            100: '#E8F5E9',
            500: '#10B981',
          }
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'],
        display: ['Space Grotesk', 'Plus Jakarta Sans', 'sans-serif'],
      },
      boxShadow: {
        'glow-lime': '0 0 25px rgba(183, 243, 74, 0.25)',
        'glow-cyan': '0 0 25px rgba(53, 201, 255, 0.25)',
        'glow-lg': '0 0 35px rgba(53, 201, 255, 0.15), 0 0 15px rgba(183, 243, 74, 0.15)',
        'cyber': '0 10px 30px -5px rgba(7, 17, 31, 0.8), 0 0 15px rgba(53, 201, 255, 0.12)',
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 3s ease-in-out infinite alternate',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 15px rgba(183, 243, 74, 0.2)' },
          '100%': { boxShadow: '0 0 30px rgba(53, 201, 255, 0.35)' },
        }
      }
    },
  },
  plugins: [],
}
