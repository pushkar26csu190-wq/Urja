import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Clock, 
  Sun, 
  Zap, 
  ArrowLeft, 
  CheckCircle2, 
  Flame, 
  Car, 
  Wind, 
  Waves,
  Coins,
  Menu
} from 'lucide-react';

export const PeakHourLoadShifting = () => {
  const { 
    loadShiftCalculations, 
    shiftedTasks, 
    toggleLoadShift, 
    regionConfig, 
    userProfile, 
    setActiveView,
    setIsNavPanelOpen,
    triggerConfetti 
  } = useEnergy();

  const applySchedulePreset = (presetName) => {
    if (presetName === 'all_solar') {
      ['geyser', 'washingMachine', 'evCharging', 'acPreCooling', 'dishwasher'].forEach(t => {
        if (!shiftedTasks[t]) toggleLoadShift(t);
      });
      triggerConfetti();
    }
  };

  const applianceIcons = {
    geyser: Flame,
    washingMachine: Waves,
    evCharging: Car,
    acPreCooling: Wind,
    dishwasher: Zap
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-urja-cyan-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400 shadow-md">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-urja-cyan-400/20 text-urja-cyan-300 border border-urja-cyan-400/40">
                  Pillar 3
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Smart Tier & Peak-Hour Load Shifting
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Real-time ToD (Time-of-Day) tariff synchronizer with {regionConfig?.discom || 'Local Grid'}.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white"
            title="3-Line Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          <button
            onClick={() => applySchedulePreset('all_solar')}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-extrabold bg-urja-cyan-400 hover:bg-urja-cyan-300 text-urja-navy-950 shadow-glow-cyan transition-all hover:scale-105 active:scale-95"
          >
            <Sun className="w-4 h-4" />
            <span>Shift All To Solar Window</span>
          </button>
        </div>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Peak Tariff Surge</div>
          <div className="text-2xl sm:text-3xl font-black text-rose-400">
            ₹{regionConfig?.peakTariff || '11.50'}
            <span className="text-sm font-semibold text-slate-400 ml-1">/kWh</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Active 18:00 - 22:00 Daily
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Solar Green Tariff</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-lime-400">
            ₹{regionConfig?.solarGreenTariff || '4.60'}
            <span className="text-sm font-semibold text-slate-400 ml-1">/kWh</span>
          </div>
          <div className="text-[11px] text-urja-lime-400 mt-1 font-semibold">
            ₹{loadShiftCalculations?.tariffDiff || '6.90'}/unit direct savings!
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Monthly Cash Saved</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-cyan-300">
            ₹{(loadShiftCalculations?.monthlySavingsRupees || 620).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            ₹{(loadShiftCalculations?.annualSavingsRupees || 7400).toLocaleString()} yearly savings
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Load Shift Progress</div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            {loadShiftCalculations?.shiftedPercentage || 60}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {loadShiftCalculations?.monthlyKwhShifted || 90} kWh moved to green hours
          </div>
        </div>

      </div>

      {/* 24-Hour Time-of-Day Tariff Zone Visualizer */}
      <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-400" />
              <span>24-Hour Time-of-Day (ToD) Dynamic Tariff Schedule</span>
            </h3>
            <p className="text-xs text-slate-400">
              Shift heavy appliance cycles into the green <strong className="text-urja-lime-400">Solar Hours (10:00 - 15:00)</strong> to pay 60% less per unit.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-urja-lime-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-urja-lime-400"></span> Solar Window (₹{regionConfig?.solarGreenTariff})
            </span>
            <span className="flex items-center gap-1.5 text-slate-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> Normal (₹{regionConfig?.baseTariff})
            </span>
            <span className="flex items-center gap-1.5 text-rose-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span> Peak Surge (₹{regionConfig?.peakTariff})
            </span>
          </div>
        </div>

        {/* 24-Hour Timeline Bar */}
        <div className="space-y-2">
          <div className="h-12 w-full rounded-2xl overflow-hidden flex shadow-inner text-[10px] font-bold text-urja-navy-950">
            <div className="w-[25%] bg-slate-500 text-white flex items-center justify-center p-1">
              <span className="truncate">00:00 - 06:00 (Night)</span>
            </div>
            <div className="w-[16.6%] bg-slate-400 text-urja-navy-950 flex items-center justify-center p-1">
              <span className="truncate">06:00 - 10:00</span>
            </div>
            <div className="w-[20.8%] bg-gradient-to-r from-urja-lime-500 to-urja-cyan-400 flex items-center justify-center p-1 shadow-glow-lime">
              <span className="flex items-center gap-1 truncate font-black text-urja-navy-950">
                <Sun className="w-3.5 h-3.5" /> 10:00 - 15:00 (Solar)
              </span>
            </div>
            <div className="w-[12.5%] bg-slate-400 text-urja-navy-950 flex items-center justify-center p-1">
              <span className="truncate">15:00 - 18:00</span>
            </div>
            <div className="w-[16.6%] bg-rose-500 text-white flex items-center justify-center p-1 animate-pulse">
              <span className="truncate font-black">18:00 - 22:00 (PEAK)</span>
            </div>
            <div className="w-[8.5%] bg-slate-500 text-white flex items-center justify-center p-1">
              <span className="truncate">22-24</span>
            </div>
          </div>
        </div>
      </div>

      {/* Shiftable Appliances Scheduler */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-white">
            Shift Heavy Loads to Solar Window
          </h3>
          <p className="text-xs text-slate-400">
            Click to shift any appliance from the expensive evening/morning peak to the solar green tariff window.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(loadShiftCalculations?.loads || []).map((load) => {
            const Icon = applianceIcons[load.id] || Zap;
            const monthlySavings = Math.round(load.kwhDaily * 30 * ((regionConfig?.peakTariff || 11.5) - (regionConfig?.solarGreenTariff || 4.6)));

            return (
              <div
                key={load.id}
                className={`p-5 rounded-3xl border transition-all duration-200 ${
                  load.isShifted
                    ? 'cyber-card-lime shadow-glow-lime'
                    : 'cyber-card'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                      load.isShifted
                        ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                        : 'bg-urja-navy-800 text-slate-400 border border-urja-navy-700'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        {load.name}
                      </h4>
                      <div className="text-xs text-slate-400">
                        {load.kwhDaily} kWh daily consumption
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleLoadShift(load.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      load.isShifted
                        ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                        : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {load.isShifted ? '✓ Shifted to Solar' : 'Shift Load'}
                  </button>
                </div>

                <div className="mt-4 pt-3 border-t border-urja-navy-750 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Unoptimized Time:</span>
                    <span className="font-semibold text-rose-400">Peak Hours (₹{regionConfig?.peakTariff}/kWh)</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Smart Shifted Time:</span>
                    <span className="font-semibold text-urja-lime-400">11:00 AM Solar (₹{regionConfig?.solarGreenTariff}/kWh)</span>
                  </div>
                </div>

                <div className="mt-3 p-2.5 rounded-xl bg-urja-navy-900 border border-urja-navy-750 flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-400">Monthly Cost Difference:</span>
                  <span className="text-urja-lime-400 font-black">
                    +₹{monthlySavings.toLocaleString()} Saved / month
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
