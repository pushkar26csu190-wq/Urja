import React from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Menu, 
  Zap, 
  Bell, 
  Sliders, 
  Coins, 
  Compass, 
  Calculator, 
  Sun,
  Moon
} from 'lucide-react';

export const Navbar = () => {
  const { 
    activeView, 
    setActiveView, 
    isNavPanelOpen, 
    setIsNavPanelOpen, 
    userProfile, 
    notifications, 
    showNotificationDrawer, 
    setShowNotificationDrawer, 
    greenCoins, 
    ecoScore,
    theme,
    toggleTheme
  } = useEnergy();

  const unreadCount = notifications?.length || 0;

  return (
    <header className="sticky top-0 z-40 cyber-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Left: Brand Identity & 3-Line Menu Trigger */}
          <div className="flex items-center gap-3 sm:gap-4">
            
            {/* 3-LINE PANEL HAMBURGER BUTTON */}
            <button
              onClick={() => setIsNavPanelOpen(true)}
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-urja-navy-800 border border-urja-cyan-400/40 text-urja-cyan-300 hover:border-urja-lime-400 hover:text-urja-lime-400 shadow-glow-cyan hover:shadow-glow-lime transition-all active:scale-95 group"
              title="Open 3-Line Navigation & Studio Panel"
              aria-label="Open 3-line navigation panel"
            >
              <div className="w-5 flex flex-col gap-1 items-start">
                <span className="w-5 h-0.5 bg-current rounded-full transition-all group-hover:w-4"></span>
                <span className="w-3.5 h-0.5 bg-current rounded-full transition-all group-hover:w-5"></span>
                <span className="w-4 h-0.5 bg-current rounded-full transition-all group-hover:w-3"></span>
              </div>
              <span className="hidden md:inline text-xs font-black tracking-wide uppercase">
                Menu
              </span>
            </button>

            {/* Logo */}
            <div 
              className="flex items-center gap-2.5 cursor-pointer"
              onClick={() => setActiveView('home')}
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-urja-lime-500 to-urja-cyan-400 flex items-center justify-center text-urja-navy-950 font-black shadow-glow-lime">
                <Zap className="w-5 h-5 fill-current" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-xl tracking-tight text-white">
                    URJA
                  </span>
                  <span className="text-xs font-bold text-urja-lime-400 px-1.5 py-0.5 rounded-md bg-urja-lime-500/10 border border-urja-lime-500/30">
                    ऊर्जा
                  </span>
                </div>
                <p className="text-[10px] font-medium text-slate-400 tracking-wide leading-none">
                  Power Tomorrow. Smarter Today.
                </p>
              </div>
            </div>

          </div>

          {/* Center Quick Nav Pills */}
          <div className="hidden xl:flex items-center gap-2">
            <button
              onClick={() => setActiveView('home')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeView === 'home'
                  ? 'bg-urja-navy-800 text-urja-lime-400 border border-urja-lime-500/50 shadow-glow-lime'
                  : 'text-slate-400 hover:text-white hover:bg-urja-navy-800/60'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setActiveView('dashboard')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeView === 'dashboard'
                  ? 'bg-urja-navy-800 text-urja-cyan-300 border border-urja-cyan-400/50 shadow-glow-cyan'
                  : 'text-slate-400 hover:text-white hover:bg-urja-navy-800/60'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveView('calculator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeView === 'calculator'
                  ? 'bg-urja-navy-800 text-urja-lime-400 border border-urja-lime-500/50 shadow-glow-lime'
                  : 'text-slate-400 hover:text-white hover:bg-urja-navy-800/60'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-urja-lime-400" />
              <span>Electricity Calculator</span>
            </button>
            <button
              onClick={() => setActiveView('renewables')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeView === 'renewables'
                  ? 'bg-urja-navy-800 text-urja-cyan-300 border border-urja-cyan-400/50 shadow-glow-cyan'
                  : 'text-slate-400 hover:text-white hover:bg-urja-navy-800/60'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-urja-cyan-400" />
              <span>Renewables</span>
            </button>
          </div>

          {/* Right Utilities */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Eco-Score & Coins */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-xs">
              <div className="flex items-center gap-1 text-urja-lime-400 font-bold" title="Eco-Score">
                <span className="w-2 h-2 rounded-full bg-urja-lime-400 animate-pulse"></span>
                <span>{ecoScore}</span>
                <span className="text-[10px] text-slate-500 font-normal">/100</span>
              </div>
              <div className="h-3 w-px bg-urja-navy-700"></div>
              <div className="flex items-center gap-1 text-amber-400 font-bold" title="Urja Green Coins">
                <Coins className="w-3.5 h-3.5" />
                <span>{greenCoins}</span>
              </div>
            </div>

            {/* Quick Dark/Light Theme Toggle */}
            <button
              onClick={() => toggleTheme()}
              className="p-2 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white transition-colors"
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
              aria-label="Toggle theme mode"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
            </button>

            {/* Reconfigure Inventory Button */}
            <button
              onClick={() => setActiveView('setup')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all active:scale-95"
              title="Calibrate your household appliances inventory"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Setup Inventory</span>
            </button>

            {/* Notifications Toggle */}
            <button
              onClick={() => setShowNotificationDrawer(!showNotificationDrawer)}
              className="relative p-2 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white hover:border-urja-cyan-400/50 transition-colors"
              aria-label="Alerts"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
              )}
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500"></span>
              )}
            </button>

          </div>

        </div>
      </div>
    </header>
  );
};
