import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Activity, 
  Zap, 
  AlertTriangle, 
  Power, 
  ArrowLeft, 
  CheckCircle2, 
  Clock, 
  Tv, 
  Wind, 
  Flame, 
  Refrigerator,
  Menu
} from 'lucide-react';

export const VampireLoadDiagnostics = () => {
  const { 
    inventory, 
    toggleKillStandby, 
    vampireCalculations, 
    regionConfig, 
    setActiveView,
    setIsNavPanelOpen,
    userProfile,
    triggerConfetti 
  } = useEnergy();

  // Master kill action
  const handleKillAllStandby = () => {
    (inventory?.standbyDevices || []).forEach(d => {
      if (!d.killed) toggleKillStandby(d.id);
    });
    (inventory?.airConditioners || []).forEach(ac => {
      if (!ac.isSmartPlugged) toggleKillStandby(ac.id);
    });
    (inventory?.waterHeaters || []).forEach(wh => {
      if (!wh.isSmartPlugged) toggleKillStandby(wh.id);
    });
    triggerConfetti();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-urja-lime-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shadow-md">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-rose-950/60 text-rose-300 border border-rose-800/60">
                  Pillar 1
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  "Vampire Load" & Appliance Diagnostics
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                AI baseline pattern matching for your {userProfile?.roomsCount || 3}-room {userProfile?.homeType} in {userProfile?.city}.
              </p>
            </div>
          </div>
        </div>

        {/* Master Kill Action Button & Menu */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white"
            title="3-Line Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          <button
            onClick={handleKillAllStandby}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-extrabold bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white shadow-md shadow-rose-600/30 transition-all hover:scale-105 active:scale-95"
          >
            <Power className="w-4 h-4" />
            <span>Kill All Phantom Draws</span>
          </button>
        </div>
      </div>

      {/* 4 Financial Waste Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Active Phantom Draw</div>
          <div className="text-2xl sm:text-3xl font-black text-rose-400">
            {vampireCalculations?.currentVampireWatts || 138}
            <span className="text-sm font-semibold text-slate-400 ml-1">Watts</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Running 24 / 7 / 365 uninterrupted
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Monthly Financial Waste</div>
          <div className="text-2xl sm:text-3xl font-black text-rose-400">
            ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {vampireCalculations?.billPercentage || 12}% of your power bill
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Annual Drain</div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            ₹{(vampireCalculations?.annualFinancialWaste || 9360).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            ~{(vampireCalculations?.monthlyWastedKwh || 110) * 12} kWh wasted annually
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Recovered via Relays</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-lime-400">
            +₹{(vampireCalculations?.monthlySavedCost || 0).toLocaleString()}
            <span className="text-xs font-semibold text-slate-400 ml-1">/mo</span>
          </div>
          <div className="text-[11px] text-urja-lime-400 mt-1 font-semibold">
            {vampireCalculations?.savedStandbyWatts || 0}W prevented from leaking
          </div>
        </div>

      </div>

      {/* Pulse Waveform / Baseline Anomaly Visualization Card */}
      <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400" />
              <span>Smart Meter 24-Hour Continuous Load Waveform & Baseline Floor</span>
            </h3>
            <p className="text-xs text-slate-400">
              Notice the elevated night-time floor (01:00 - 05:00). A healthy home baseline is &lt;30W. Yours is running at {vampireCalculations?.currentVampireWatts || 138}W.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-urja-lime-400 font-semibold">
              <span className="w-3 h-1.5 bg-urja-lime-400 rounded"></span> Active Demand
            </span>
            <span className="flex items-center gap-1.5 text-rose-400 font-bold">
              <span className="w-3 h-1.5 bg-rose-500 rounded"></span> Phantom Baseline ({vampireCalculations?.currentVampireWatts || 138}W)
            </span>
          </div>
        </div>

        {/* Custom SVG Oscilloscope Waveform */}
        <div className="w-full h-44 bg-urja-navy-950 rounded-2xl p-4 relative overflow-hidden flex flex-col justify-end border border-urja-navy-750">
          <div className="absolute inset-0 bg-[radial-gradient(#162E48_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>
          
          <svg className="w-full h-full relative z-10" viewBox="0 0 800 140" preserveAspectRatio="none">
            <defs>
              <linearGradient id="activeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#B7F34A" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#35C9FF" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Phantom Baseline horizontal dashed band */}
            <line 
              x1="0" 
              y1={Math.max(20, 140 - ((vampireCalculations?.currentVampireWatts || 138) / 3))} 
              x2="800" 
              y2={Math.max(20, 140 - ((vampireCalculations?.currentVampireWatts || 138) / 3))} 
              stroke="#F43F5E" 
              strokeWidth="2" 
              strokeDasharray="4 4" 
            />
            <text 
              x="10" 
              y={Math.max(16, 130 - ((vampireCalculations?.currentVampireWatts || 138) / 3))} 
              fill="#F43F5E" 
              fontSize="11" 
              fontWeight="bold"
            >
              Vampire Baseline: {vampireCalculations?.currentVampireWatts || 138} Watts Continuous Draw
            </text>

            {/* 24-hr Load Curve */}
            <path
              d="M0,110 Q40,110 80,105 T160,110 T240,85 T320,60 T400,90 T480,80 T560,40 T640,30 T720,70 T800,105 L800,140 L0,140 Z"
              fill="url(#activeGrad)"
            />
            <path
              d="M0,110 Q40,110 80,105 T160,110 T240,85 T320,60 T400,90 T480,80 T560,40 T640,30 T720,70 T800,105"
              fill="none"
              stroke="#B7F34A"
              strokeWidth="2.5"
            />
          </svg>

          {/* Time markers */}
          <div className="relative z-10 flex justify-between text-[10px] text-slate-500 pt-2 border-t border-urja-navy-800">
            <span>00:00 (Sleep)</span>
            <span>04:00</span>
            <span>08:00 (Morning)</span>
            <span>12:00 (Solar Peak)</span>
            <span>16:00</span>
            <span>20:00 (Evening Surge)</span>
            <span>23:59</span>
          </div>
        </div>
      </div>

      {/* Individual Controls */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-white">
            Appliance Health Diagnostic Breakdown & Relays
          </h3>
          <p className="text-xs text-slate-400">
            Toggle smart relays to cut phantom load or review mechanical compressor health score.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Refrigerators */}
          {(inventory?.refrigerators || []).map((rf) => {
            const hasAnomaly = (rf.ageYears || 0) > 5 || (rf.starRating || 3) <= 2;
            return (
              <div 
                key={rf.id}
                className={`p-5 rounded-2xl border transition-all ${
                  hasAnomaly 
                    ? 'bg-amber-950/20 border-amber-500/40' 
                    : 'cyber-card'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-urja-lime-400/10 border border-urja-lime-400/30 flex items-center justify-center text-urja-lime-400">
                      <Refrigerator className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white">{rf.name}</div>
                      <div className="text-xs text-slate-400">{rf.type} • {rf.ageYears} Yrs Old</div>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleKillStandby(rf.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      rf.isSmartPlugged
                        ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                        : 'bg-urja-navy-800 text-slate-300 border border-urja-navy-700 hover:text-white'
                    }`}
                  >
                    {rf.isSmartPlugged ? '✓ Standby Cut' : 'Plug Cutoff'}
                  </button>
                </div>

                <div className="mt-4 pt-3 border-t border-urja-navy-750">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-semibold text-slate-300">Appliance Health Score</span>
                    <span className={`font-black ${(rf.healthScore || 70) < 60 ? 'text-rose-400' : 'text-urja-lime-400'}`}>
                      {rf.healthScore || 70}/100 {(rf.healthScore || 70) < 60 ? '(Degraded)' : '(Healthy)'}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${(rf.healthScore || 70) < 60 ? 'bg-rose-500' : 'bg-urja-lime-400'}`}
                      style={{ width: `${rf.healthScore || 70}%` }}
                    />
                  </div>
                </div>

                {hasAnomaly && (
                  <div className="mt-3 p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold">Compressor Short-Cycling Anomaly</div>
                      <p className="mt-0.5 text-[11px] leading-relaxed">
                        Motor kicks on 14 times/hr (vs 4 nominal). Worn magnetic seal leaking cold air adds <strong>+45 Watts</strong> constant draw (₹320/mo waste).
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* ACs */}
          {(inventory?.airConditioners || []).map((ac) => (
            <div key={ac.id} className="cyber-card rounded-2xl p-5 shadow-cyber">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400">
                    <Wind className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{ac.name}</div>
                    <div className="text-xs text-slate-400">{ac.tonnage} Ton • {ac.starRating}-Star • {ac.ageYears} Yrs Old</div>
                  </div>
                </div>

                <button
                  onClick={() => toggleKillStandby(ac.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    ac.isSmartPlugged
                      ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                      : 'bg-urja-navy-800 text-slate-300 border border-urja-navy-700 hover:text-white'
                  }`}
                >
                  {ac.isSmartPlugged ? '✓ Standby Cut' : 'Plug Cutoff'}
                </button>
              </div>

              <div className="mt-4 pt-3 border-t border-urja-navy-750 flex items-center justify-between text-xs">
                <span className="text-slate-400">PCB & Remote Receiver Standby:</span>
                <span className={`font-bold ${ac.isSmartPlugged ? 'text-urja-lime-400 line-through' : 'text-rose-400'}`}>
                  {ac.standbyWatts || 14} Watts (₹{Math.round((ac.standbyWatts || 14) * 24 * 30 * (regionConfig?.baseTariff || 7.2) / 1000)}/mo)
                </span>
              </div>
            </div>
          ))}

          {/* Dedicated Standby Devices */}
          {(inventory?.standbyDevices || []).map((sb) => (
            <div key={sb.id} className="cyber-card rounded-2xl p-4 shadow-cyber flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-urja-navy-800 border border-urja-navy-700 flex items-center justify-center text-slate-400">
                  <Tv className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">{sb.name}</div>
                  <div className="text-[11px] text-slate-400">{sb.location} • {sb.watts}W standby draw</div>
                </div>
              </div>

              <button
                onClick={() => toggleKillStandby(sb.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  sb.killed
                    ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                    : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
                }`}
              >
                {sb.killed ? '✓ Standby Dead' : 'Kill Vampire'}
              </button>
            </div>
          ))}

        </div>
      </div>

    </div>
  );
};
