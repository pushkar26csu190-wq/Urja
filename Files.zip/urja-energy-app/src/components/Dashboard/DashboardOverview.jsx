import React from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Zap, 
  Activity, 
  TrendingUp, 
  Clock, 
  Sun, 
  ArrowRight, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle, 
  Leaf, 
  Coins, 
  Calculator, 
  Compass,
  Menu
} from 'lucide-react';

export const DashboardOverview = () => {
  const { 
    userProfile, 
    regionConfig, 
    inventory, 
    setActiveView, 
    setIsNavPanelOpen,
    vampireCalculations, 
    retrofitCalculations, 
    loadShiftCalculations, 
    solarCalculations,
    ecoScore,
    greenCoins 
  } = useEnergy();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-urja-cyan-400/20 text-urja-cyan-300 border border-urja-cyan-400/40">
              Executive IoT Matrix
            </span>
            <span className="text-xs text-slate-500">•</span>
            <span className="text-xs text-slate-400">{userProfile?.homeType || 'Apartment'} in {userProfile?.city || 'Bengaluru'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            Household Energy Intelligence Dashboard
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold bg-urja-navy-800 border border-urja-cyan-400/40 text-urja-cyan-300 hover:text-white transition-all shadow-glow-cyan"
          >
            <Menu className="w-3.5 h-3.5" />
            <span>3-Line Panel</span>
          </button>
          <button
            onClick={() => setActiveView('setup')}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:border-urja-lime-400 hover:text-urja-lime-400 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Edit Inventory</span>
          </button>
          <button
            onClick={() => setActiveView('home')}
            className="px-4 py-2 rounded-xl text-xs font-black bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all"
          >
            Minimal Home
          </button>
        </div>
      </div>

      {/* 4 Summary Scorecards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Eco Score */}
        <div className="cyber-card rounded-2xl p-5 shadow-cyber">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Home Eco-Score</span>
            <span className="w-2.5 h-2.5 rounded-full bg-urja-lime-400 animate-pulse"></span>
          </div>
          <div className="text-3xl font-black text-white">
            {ecoScore}
            <span className="text-sm font-semibold text-slate-400 ml-1">/100</span>
          </div>
          <div className="w-full h-1.5 bg-urja-navy-800 rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-urja-lime-400 rounded-full" style={{ width: `${ecoScore}%` }} />
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Top 18% in {userProfile?.city?.split(',')[0] || 'your city'}
          </div>
        </div>

        {/* Monthly Waste */}
        <div className="cyber-card rounded-2xl p-5 shadow-cyber">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Phantom Waste</span>
            <Activity className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-rose-400">
            ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            {vampireCalculations?.currentVampireWatts || 138}W continuous baseline
          </div>
        </div>

        {/* Total Recoverable Savings */}
        <div className="cyber-card rounded-2xl p-5 shadow-cyber">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Monthly Unlockable</span>
            <TrendingUp className="w-4 h-4 text-urja-lime-400" />
          </div>
          <div className="text-3xl font-black text-urja-lime-400">
            ₹{((retrofitCalculations?.monthlyMoneySaved || 1850) + (loadShiftCalculations?.monthlySavingsRupees || 620)).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Retrofit + Solar Window Shifting
          </div>
        </div>

        {/* Solar Subsidy */}
        <div className="cyber-card rounded-2xl p-5 shadow-cyber">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">PM Surya Ghar Subsidy</span>
            <Sun className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-amber-400">
            ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Direct Central + State grant
          </div>
        </div>

      </div>

      {/* Appliance Load Distribution & 4 Pillar Studios */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Load Distribution */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <h3 className="text-base font-bold text-white">
            Appliance Energy Footprint Breakdown
          </h3>
          <p className="text-xs text-slate-400">
            Calibrated for your {inventory?.airConditioners?.length || 2} ACs, {inventory?.waterHeaters?.length || 2} geysers, and {inventory?.fansCount || 6} fans.
          </p>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-urja-cyan-300">Air Conditioning ({inventory?.airConditioners?.length || 2} Units)</span>
                <span>48%</span>
              </div>
              <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                <div className="h-full bg-urja-cyan-400 rounded-full" style={{ width: '48%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-amber-400">Water Heating ({inventory?.waterHeaters?.length || 2} Geysers)</span>
                <span>22%</span>
              </div>
              <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                <div className="h-full bg-amber-400 rounded-full" style={{ width: '22%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-purple-400">Refrigeration & Cooling</span>
                <span>15%</span>
              </div>
              <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                <div className="h-full bg-purple-400 rounded-full" style={{ width: '15%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-rose-400">Vampire Phantom Draw</span>
                <span>11%</span>
              </div>
              <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 rounded-full" style={{ width: '11%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-urja-lime-400">Lighting & Fans</span>
                <span>4%</span>
              </div>
              <div className="w-full h-2 bg-urja-navy-800 rounded-full overflow-hidden">
                <div className="h-full bg-urja-lime-400 rounded-full" style={{ width: '4%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* 4 Pillars Studios & Tools Launchpad */}
        <div className="lg:col-span-2 cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">
              Direct Pillar Navigation & Interactive Studios
            </h3>
            <span className="text-xs text-slate-400">Click any card to launch studio</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            
            <div 
              onClick={() => setActiveView('vampire')}
              className="p-4 rounded-2xl bg-urja-navy-900 border border-rose-500/30 cursor-pointer hover:border-rose-400 transition-all hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                  <Activity className="w-4 h-4" /> Pillar 1: Vampire Load
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-rose-400" />
              </div>
              <div className="text-sm font-bold text-white">
                Kill {vampireCalculations?.currentVampireWatts || 138}W Baseline Draw
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Save ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()}/mo with smart relay timers.
              </p>
            </div>

            <div 
              onClick={() => setActiveView('retrofit')}
              className="p-4 rounded-2xl bg-urja-navy-900 border border-urja-lime-500/30 cursor-pointer hover:border-urja-lime-400 transition-all hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-urja-lime-400 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4" /> Pillar 2: Retrofit ROI
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-urja-lime-400" />
              </div>
              <div className="text-sm font-bold text-white">
                5-Star Inverters & BLDC Fans
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Payback in {retrofitCalculations?.paybackYears || '2.1'} yrs • ₹{(retrofitCalculations?.annualMoneySaved || 22000).toLocaleString()} saved/yr.
              </p>
            </div>

            <div 
              onClick={() => setActiveView('loadshift')}
              className="p-4 rounded-2xl bg-urja-navy-900 border border-urja-cyan-400/30 cursor-pointer hover:border-urja-cyan-400 transition-all hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-urja-cyan-300 flex items-center gap-1.5">
                  <Clock className="w-4 h-4" /> Pillar 3: Peak Load Shift
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-urja-cyan-300" />
              </div>
              <div className="text-sm font-bold text-white">
                Dodge Evening Surge Tariffs
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Shift to 10-15h solar green hours • Save ₹{(loadShiftCalculations?.monthlySavingsRupees || 620).toLocaleString()}/mo.
              </p>
            </div>

            <div 
              onClick={() => setActiveView('solar')}
              className="p-4 rounded-2xl bg-urja-navy-900 border border-amber-500/30 cursor-pointer hover:border-amber-400 transition-all hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <Sun className="w-4 h-4" /> Pillar 4: Urja-Mitra Solar
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-sm font-bold text-white">
                PM Surya Ghar Scheme
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()} grant • +₹{(solarCalculations?.instantMonthlyCashflow || 1800).toLocaleString()} monthly profit.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
