import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { ECO_LEADERBOARD } from '../../data/mockData';
import { 
  Award, 
  Coins, 
  ArrowLeft, 
  Trophy, 
  CheckCircle2, 
  Gift, 
  MapPin, 
  Menu 
} from 'lucide-react';

export const CommunityLeaderboard = () => {
  const { 
    userProfile, 
    greenCoins, 
    setGreenCoins, 
    ecoScore, 
    setActiveView, 
    setIsNavPanelOpen,
    triggerConfetti 
  } = useEnergy();

  const [redeemedItem, setRedeemedItem] = useState(null);

  const rewards = [
    {
      id: 'reward-1',
      title: 'URJA 16A Smart Energy Relay Plug',
      costCoins: 350,
      description: 'WiFi smart plug with real-time current sensing and automated vampire cutoff.',
      category: 'Hardware'
    },
    {
      id: 'reward-2',
      title: '₹250 DISCOM Electricity Bill Credit Voucher',
      costCoins: 250,
      description: 'Direct rebate voucher credited on your next utility power bill.',
      category: 'Bill Credit'
    },
    {
      id: 'reward-3',
      title: '10% Discount on BEE 5-Star BLDC Fan Upgrade',
      costCoins: 150,
      description: 'Partner discount coupon on Atomberg or Havells BLDC fans.',
      category: 'Retrofit Perk'
    },
    {
      id: 'reward-4',
      title: 'Adopt a Native Urban Tree in Clean Corridor',
      costCoins: 100,
      description: 'Plant and geolocate an urban tree to offset household carbon footprint.',
      category: 'Eco-Action'
    }
  ];

  const handleRedeem = (reward) => {
    if (greenCoins >= reward.costCoins) {
      setGreenCoins(c => c - reward.costCoins);
      setRedeemedItem(reward.title);
      triggerConfetti();
      setTimeout(() => setRedeemedItem(null), 4000);
    } else {
      alert(`You need ${reward.costCoins - greenCoins} more Urja Coins. Cut phantom load or shift cycles to earn more!`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-amber-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 shadow-md">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/40">
                  Community
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Neighborhood Eco-Leaderboard & Rewards
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Competing with 1,420 households across {userProfile?.city?.split(',')[0] || 'your city'} for zero-waste grid stability.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white"
            title="3-Line Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          
          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-urja-navy-800 border border-amber-500/40 shadow-glow-amber">
            <div className="w-7 h-7 rounded-lg bg-amber-400 flex items-center justify-center text-urja-navy-950 font-bold">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-bold">Urja Coins</div>
              <div className="text-sm font-black text-amber-400">{greenCoins} Coins</div>
            </div>
          </div>
        </div>
      </div>

      {redeemedItem && (
        <div className="p-4 rounded-2xl bg-urja-lime-500 text-urja-navy-950 flex items-center justify-between shadow-glow-lime animate-fadeIn font-bold">
          <div className="flex items-center gap-3 text-xs">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <div>
              <span className="font-black text-sm">Reward Claimed!</span>
              <p>You unlocked: {redeemedItem}. Code dispatched to your dashboard.</p>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard Table & Store */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Leaderboard */}
        <div className="lg:col-span-2 cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>{userProfile?.city?.split(',')[0] || 'City'} Green Living Rank</span>
            </h3>
            <span className="text-xs text-slate-400">Smart meter synced</span>
          </div>

          <div className="divide-y divide-urja-navy-750">
            {ECO_LEADERBOARD.map((user) => {
              const isCurrentUser = user.rank === 4;
              return (
                <div 
                  key={user.rank}
                  className={`py-3.5 px-3 flex items-center justify-between rounded-xl transition-all ${
                    isCurrentUser 
                      ? 'bg-urja-navy-800/90 border border-urja-lime-500/50 font-bold shadow-glow-lime' 
                      : 'hover:bg-urja-navy-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black ${
                      user.rank === 1 ? 'bg-amber-400 text-urja-navy-950' :
                      user.rank === 2 ? 'bg-slate-300 text-urja-navy-950' :
                      user.rank === 3 ? 'bg-amber-600 text-white' :
                      'bg-urja-navy-800 text-slate-400 border border-urja-navy-700'
                    }`}>
                      {user.rank}
                    </div>

                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{isCurrentUser ? `${userProfile?.name} (You)` : user.name}</span>
                        {isCurrentUser && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-urja-lime-500 text-urja-navy-950 font-black">
                            Current
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-urja-cyan-400" />
                        <span>{user.locality}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <div className="hidden sm:block text-right">
                      <div className="text-urja-lime-400 font-bold">-{user.monthlySavedKwh} kWh/mo</div>
                      <div className="text-[10px] text-slate-400">{user.badge}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-black text-white">{isCurrentUser ? ecoScore : user.score}</div>
                      <div className="text-[10px] text-slate-400">Score</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Store */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Gift className="w-4 h-4 text-urja-cyan-300" />
              <span>URJA Green Store</span>
            </h3>
            <span className="text-xs text-amber-400 font-bold">{greenCoins} Coins</span>
          </div>

          <div className="space-y-3 pt-2">
            {rewards.map((rew) => (
              <div 
                key={rew.id}
                className="p-3.5 rounded-2xl bg-urja-navy-900 border border-urja-navy-750 space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="text-xs font-bold text-white leading-tight">
                    {rew.title}
                  </div>
                  <span className="text-xs font-black text-amber-400 shrink-0">
                    {rew.costCoins}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {rew.description}
                </p>
                <button
                  onClick={() => handleRedeem(rew)}
                  disabled={greenCoins < rew.costCoins}
                  className={`w-full py-1.5 rounded-xl text-xs font-bold transition-all ${
                    greenCoins >= rew.costCoins
                      ? 'bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 font-black shadow-glow-lime'
                      : 'bg-urja-navy-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  {greenCoins >= rew.costCoins ? 'Redeem Voucher' : `Need ${rew.costCoins - greenCoins} More`}
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
