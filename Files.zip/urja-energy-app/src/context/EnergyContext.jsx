import React, { createContext, useContext, useState, useMemo, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { REGIONAL_DATA, HOME_PRESETS, RETROFIT_CATALOG, ECO_LEADERBOARD, INITIAL_NOTIFICATIONS } from '../data/mockData';

const EnergyContext = createContext();

export const useEnergy = () => {
  const context = useContext(EnergyContext);
  if (!context) {
    throw new Error('useEnergy must be used within an EnergyProvider');
  }
  return context;
};

export const EnergyProvider = ({ children }) => {
  // Navigation / View State
  const [activeView, setActiveView] = useState('home');
  const [isNavPanelOpen, setIsNavPanelOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(true);

  // Theme State: 'dark' (default futuristic deep navy) or 'light'
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('urja_theme') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
      }
      localStorage.setItem('urja_theme', theme);
    }
  }, [theme]);

  const toggleTheme = (explicitTheme) => {
    if (explicitTheme) {
      setTheme(explicitTheme);
    } else {
      setTheme(t => t === 'dark' ? 'light' : 'dark');
    }
  };
  
  // Safe confetti helper
  const triggerConfetti = () => {
    try {
      if (typeof window !== 'undefined') {
        confetti({
          particleCount: 65,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#B7F34A', '#35C9FF', '#FFFFFF', '#9FE628']
        });
      }
    } catch (e) {
      console.warn('Confetti skipped safely:', e);
    }
  };

  // Notifications Queue
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);
  const [showNotificationDrawer, setShowNotificationDrawer] = useState(false);
  const [greenCoins, setGreenCoins] = useState(420);

  // User Profile & Region
  const [userProfile, setUserProfile] = useState({
    name: 'Aarav Patel',
    email: 'aarav.patel@greentech.in',
    state: 'Karnataka',
    city: 'Indiranagar, Bengaluru',
    homeType: 'Apartment (3BHK)',
    roomsCount: 3,
    monthlyBill: 6200,
    roofAreaSqFt: 450,
    hasRooftopAccess: true,
  });

  // Current Regional DISCOM parameters
  const regionConfig = useMemo(() => {
    return REGIONAL_DATA[userProfile?.state] || REGIONAL_DATA['Karnataka'];
  }, [userProfile?.state]);

  // Household Appliances Inventory State
  const [inventory, setInventory] = useState({
    airConditioners: HOME_PRESETS['3bhk'].airConditioners,
    refrigerators: HOME_PRESETS['3bhk'].refrigerators,
    waterHeaters: HOME_PRESETS['3bhk'].waterHeaters,
    fansCount: HOME_PRESETS['3bhk'].fansCount,
    bldcFansCount: HOME_PRESETS['3bhk'].bldcFansCount,
    cflTubesCount: HOME_PRESETS['3bhk'].cflTubesCount,
    ledBulbsCount: HOME_PRESETS['3bhk'].ledBulbsCount,
    standbyDevices: HOME_PRESETS['3bhk'].standbyDevices,
  });

  // Load Shifting tasks scheduled state
  const [shiftedTasks, setShiftedTasks] = useState({
    geyser: true,
    washingMachine: true,
    evCharging: false,
    acPreCooling: false,
    dishwasher: true
  });

  // Retrofit Selected Upgrades
  const [selectedRetrofits, setSelectedRetrofits] = useState(['ac_upgrade', 'bldc_fan', 'led_conversion']);

  // Apply quick preset
  const applyPreset = (presetKey) => {
    const preset = HOME_PRESETS[presetKey];
    if (!preset) return;
    setInventory({
      airConditioners: JSON.parse(JSON.stringify(preset.airConditioners || [])),
      refrigerators: JSON.parse(JSON.stringify(preset.refrigerators || [])),
      waterHeaters: JSON.parse(JSON.stringify(preset.waterHeaters || [])),
      fansCount: preset.fansCount || 4,
      bldcFansCount: preset.bldcFansCount || 0,
      cflTubesCount: preset.cflTubesCount || 4,
      ledBulbsCount: preset.ledBulbsCount || 6,
      standbyDevices: JSON.parse(JSON.stringify(preset.standbyDevices || [])),
    });
    setUserProfile(prev => ({
      ...prev,
      roomsCount: preset.roomsCount || 3,
      homeType: preset.homeType || 'Apartment',
      monthlyBill: preset.monthlyBill || 5000
    }));
  };

  // Toggle killing standby for a standby device or appliance
  const toggleKillStandby = (deviceId) => {
    setInventory(prev => {
      const updatedStandby = (prev.standbyDevices || []).map(d => {
        if (d.id === deviceId) {
          const newKilled = !d.killed;
          if (newKilled) setGreenCoins(c => c + 15);
          return { ...d, killed: newKilled };
        }
        return d;
      });

      const updatedAcs = (prev.airConditioners || []).map(ac => {
        if (ac.id === deviceId) {
          const newPlug = !ac.isSmartPlugged;
          if (newPlug) setGreenCoins(c => c + 20);
          return { ...ac, isSmartPlugged: newPlug };
        }
        return ac;
      });

      const updatedWh = (prev.waterHeaters || []).map(wh => {
        if (wh.id === deviceId) {
          const newPlug = !wh.isSmartPlugged;
          if (newPlug) setGreenCoins(c => c + 20);
          return { ...wh, isSmartPlugged: newPlug };
        }
        return wh;
      });

      const updatedRef = (prev.refrigerators || []).map(rf => {
        if (rf.id === deviceId) {
          const newPlug = !rf.isSmartPlugged;
          if (newPlug) setGreenCoins(c => c + 25);
          return { ...rf, isSmartPlugged: newPlug };
        }
        return rf;
      });

      return {
        ...prev,
        standbyDevices: updatedStandby,
        airConditioners: updatedAcs,
        waterHeaters: updatedWh,
        refrigerators: updatedRef
      };
    });
  };

  // Toggle load shift schedule
  const toggleLoadShift = (taskId) => {
    setShiftedTasks(prev => {
      const updated = !prev[taskId];
      if (updated) setGreenCoins(c => c + 25);
      return { ...prev, [taskId]: updated };
    });
  };

  // Toggle Retrofit item
  const toggleRetrofit = (retrofitId) => {
    setSelectedRetrofits(prev => {
      if (prev.includes(retrofitId)) {
        return prev.filter(id => id !== retrofitId);
      } else {
        return [...prev, retrofitId];
      }
    });
  };

  // Dynamic calculations derived with safe defaults
  const baseTariff = Number(regionConfig?.baseTariff || 7.20);
  const peakTariff = Number(regionConfig?.peakTariff || 11.50);
  const solarGreenTariff = Number(regionConfig?.solarGreenTariff || 4.60);

  const billAmount = Number(userProfile?.monthlyBill || 5000);
  const monthlyKwh = Math.max(50, Math.round(billAmount / (baseTariff || 1)));
  const dailyKwh = (monthlyKwh / 30).toFixed(1);

  // Vampire Load Calculations
  const vampireCalculations = useMemo(() => {
    let activeStandbyWatts = 0;
    let savedStandbyWatts = 0;
    let totalPotentialWatts = 0;

    (inventory.airConditioners || []).forEach(ac => {
      const w = Number(ac.standbyWatts || 14);
      totalPotentialWatts += w;
      if (ac.isSmartPlugged) savedStandbyWatts += w;
      else activeStandbyWatts += w;
    });

    (inventory.waterHeaters || []).forEach(wh => {
      const w = Number(wh.standbyWatts || 22);
      totalPotentialWatts += w;
      if (wh.isSmartPlugged) savedStandbyWatts += w;
      else activeStandbyWatts += w;
    });

    (inventory.standbyDevices || []).forEach(sb => {
      const w = Number(sb.watts || 12);
      totalPotentialWatts += w;
      if (sb.killed) savedStandbyWatts += w;
      else activeStandbyWatts += w;
    });

    let fridgeAnomalyWatts = 0;
    (inventory.refrigerators || []).forEach(rf => {
      if (Number(rf.ageYears || 0) > 5 || Number(rf.starRating || 3) <= 2) {
        fridgeAnomalyWatts += 45;
      }
      const w = Number(rf.standbyWatts || 25);
      totalPotentialWatts += w;
      if (rf.isSmartPlugged) savedStandbyWatts += w;
      else activeStandbyWatts += w;
    });

    const currentVampireWatts = activeStandbyWatts + fridgeAnomalyWatts;
    const monthlyWastedKwh = Math.round((currentVampireWatts * 24 * 30) / 1000);
    const monthlyFinancialWaste = Math.round(monthlyWastedKwh * baseTariff);
    const annualFinancialWaste = monthlyFinancialWaste * 12;
    const billPercentage = Math.min(30, Math.round((monthlyFinancialWaste / (billAmount || 1)) * 100));

    const monthlySavedKwh = Math.round((savedStandbyWatts * 24 * 30) / 1000);
    const monthlySavedCost = Math.round(monthlySavedKwh * baseTariff);

    return {
      currentVampireWatts,
      savedStandbyWatts,
      totalPotentialWatts: totalPotentialWatts + fridgeAnomalyWatts,
      monthlyWastedKwh,
      monthlyFinancialWaste,
      annualFinancialWaste,
      billPercentage,
      monthlySavedKwh,
      monthlySavedCost,
      fridgeAnomalyWatts
    };
  }, [inventory, baseTariff, billAmount]);

  // Retrofit ROI Calculations
  const retrofitCalculations = useMemo(() => {
    let totalUpfrontCost = 0;
    let totalSubsidy = 0;
    let annualKwhSaved = 0;

    if (selectedRetrofits.includes('ac_upgrade')) {
      const acCount = Math.max(1, (inventory.airConditioners || []).length);
      totalUpfrontCost += 42000 * acCount;
      totalSubsidy += 3500 * acCount;
      annualKwhSaved += 640 * acCount;
    }

    if (selectedRetrofits.includes('bldc_fan')) {
      const regularFans = Math.max(1, (inventory.fansCount || 5) - (inventory.bldcFansCount || 0));
      totalUpfrontCost += 2800 * regularFans;
      totalSubsidy += 300 * regularFans;
      annualKwhSaved += 145 * regularFans;
    }

    if (selectedRetrofits.includes('led_conversion')) {
      const tubes = Math.max(1, inventory.cflTubesCount || 4);
      totalUpfrontCost += 140 * tubes;
      totalSubsidy += 20 * tubes;
      annualKwhSaved += 68 * tubes;
    }

    if (selectedRetrofits.includes('heatpump_geyser')) {
      const geysersCount = Math.max(1, (inventory.waterHeaters || []).length);
      totalUpfrontCost += 18500 * geysersCount;
      totalSubsidy += 2000 * geysersCount;
      annualKwhSaved += 480 * geysersCount;
    }

    const netInvestment = Math.max(0, totalUpfrontCost - totalSubsidy);
    const annualMoneySaved = Math.round(annualKwhSaved * baseTariff);
    const monthlyMoneySaved = Math.round(annualMoneySaved / 12);
    const paybackYears = annualMoneySaved > 0 ? (netInvestment / annualMoneySaved).toFixed(1) : '1.8';
    const paybackMonths = Math.round(Number(paybackYears) * 12);
    const fiveYearNetReturn = Math.round((annualMoneySaved * 5) - netInvestment);
    const tenYearNetReturn = Math.round((annualMoneySaved * 10) - netInvestment);
    const co2TonnesPerYear = (annualKwhSaved * 0.82 / 1000).toFixed(2);

    return {
      totalUpfrontCost,
      totalSubsidy,
      netInvestment,
      annualKwhSaved,
      annualMoneySaved,
      monthlyMoneySaved,
      paybackYears,
      paybackMonths,
      fiveYearNetReturn,
      tenYearNetReturn,
      co2TonnesPerYear
    };
  }, [selectedRetrofits, inventory, baseTariff]);

  // Load Shifting Calculations
  const loadShiftCalculations = useMemo(() => {
    const tariffDiff = Math.max(2, peakTariff - solarGreenTariff);

    const loads = [
      { id: 'geyser', name: 'Morning Water Heating (2kW)', kwhDaily: 2.4, isShifted: Boolean(shiftedTasks.geyser) },
      { id: 'washingMachine', name: 'Washing Machine Cycle', kwhDaily: 1.8, isShifted: Boolean(shiftedTasks.washingMachine) },
      { id: 'evCharging', name: 'EV 2-Wheeler / Car Top-up', kwhDaily: 3.5, isShifted: Boolean(shiftedTasks.evCharging) },
      { id: 'acPreCooling', name: 'Room Pre-Cooling before Peak', kwhDaily: 2.2, isShifted: Boolean(shiftedTasks.acPreCooling) },
      { id: 'dishwasher', name: 'Dishwasher Eco Cycle', kwhDaily: 1.4, isShifted: Boolean(shiftedTasks.dishwasher) },
    ];

    let monthlyKwhShifted = 0;
    let monthlySavingsRupees = 0;
    let potentialMaxSavingsRupees = 0;

    loads.forEach(load => {
      const kwh = load.kwhDaily * 30;
      const maxSavings = kwh * tariffDiff;
      potentialMaxSavingsRupees += maxSavings;
      if (load.isShifted) {
        monthlyKwhShifted += kwh;
        monthlySavingsRupees += maxSavings;
      }
    });

    const shiftedPercentage = Math.round((monthlySavingsRupees / (potentialMaxSavingsRupees || 1)) * 100);

    return {
      loads,
      monthlyKwhShifted: Math.round(monthlyKwhShifted),
      monthlySavingsRupees: Math.round(monthlySavingsRupees),
      annualSavingsRupees: Math.round(monthlySavingsRupees * 12),
      potentialMaxSavingsRupees: Math.round(potentialMaxSavingsRupees),
      shiftedPercentage,
      tariffDiff: tariffDiff.toFixed(2)
    };
  }, [peakTariff, solarGreenTariff, shiftedTasks]);

  // Urja-Mitra Solar & Subsidy Auto-Matcher
  const solarCalculations = useMemo(() => {
    const recommendedCapacityKw = Math.min(10, Math.max(1, Math.round((monthlyKwh / 120) * 10) / 10));
    const requiredRoofSqFt = Math.round(recommendedCapacityKw * 95);
    const estimatedMonthlyGenerationKwh = Math.round(recommendedCapacityKw * 120);

    const grossCost = Math.round(recommendedCapacityKw * 58000);

    let centralSubsidy = 0;
    if (recommendedCapacityKw <= 1) {
      centralSubsidy = 30000;
    } else if (recommendedCapacityKw <= 2) {
      centralSubsidy = 60000;
    } else {
      centralSubsidy = 78000;
    }

    const stateSubsidy = Number(regionConfig?.stateSolarSubsidy || 12000);
    const totalSubsidy = centralSubsidy + stateSubsidy;
    const netCost = Math.max(15000, grossCost - totalSubsidy);

    const expectedGenerationValue = Math.round(Math.min(monthlyKwh, estimatedMonthlyGenerationKwh) * baseTariff);
    const postSolarMonthlyBill = Math.max(250, billAmount - expectedGenerationValue);
    const monthlyNetSavings = Math.max(500, billAmount - postSolarMonthlyBill);
    const annualNetSavings = monthlyNetSavings * 12;

    const paybackYears = (netCost / (annualNetSavings || 1)).toFixed(1);
    const lifetimeSavings25Years = Math.round((annualNetSavings * 25) - netCost);

    const loanPrincipal = netCost;
    const monthlyRate = 0.07 / 12;
    const tenureMonths = 60;
    const monthlyLoanEmi = Math.round(
      (loanPrincipal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) /
      (Math.pow(1 + monthlyRate, tenureMonths) - 1)
    );

    const instantMonthlyCashflow = monthlyNetSavings - monthlyLoanEmi;

    return {
      recommendedCapacityKw,
      requiredRoofSqFt,
      estimatedMonthlyGenerationKwh,
      grossCost,
      centralSubsidy,
      stateSubsidy,
      totalSubsidy,
      netCost,
      postSolarMonthlyBill,
      monthlyNetSavings,
      annualNetSavings,
      paybackYears,
      lifetimeSavings25Years,
      monthlyLoanEmi,
      instantMonthlyCashflow
    };
  }, [monthlyKwh, billAmount, baseTariff, regionConfig]);

  // Overall Home Eco-Score (0 - 100)
  const ecoScore = useMemo(() => {
    let score = 65;
    if (vampireCalculations.monthlyFinancialWaste < 300) score += 10;
    else if (vampireCalculations.monthlyFinancialWaste > 800) score -= 8;
    score += Math.round(loadShiftCalculations.shiftedPercentage * 0.15);
    if (selectedRetrofits.length >= 3) score += 10;
    return Math.min(98, Math.max(40, score));
  }, [vampireCalculations, loadShiftCalculations, selectedRetrofits]);

  return (
    <EnergyContext.Provider
      value={{
        activeView,
        setActiveView,
        isNavPanelOpen,
        setIsNavPanelOpen,
        isLoggedIn,
        setIsLoggedIn,
        theme,
        setTheme,
        toggleTheme,
        userProfile,
        setUserProfile,
        regionConfig,
        inventory,
        setInventory,
        applyPreset,
        toggleKillStandby,
        toggleLoadShift,
        shiftedTasks,
        selectedRetrofits,
        toggleRetrofit,
        vampireCalculations,
        retrofitCalculations,
        loadShiftCalculations,
        solarCalculations,
        ecoScore,
        monthlyKwh,
        dailyKwh,
        greenCoins,
        setGreenCoins,
        notifications,
        setNotifications,
        showNotificationDrawer,
        setShowNotificationDrawer,
        triggerConfetti,
      }}
    >
      {children}
    </EnergyContext.Provider>
  );
};
