// Regional DISCOMs & Tariff Details
export const REGIONAL_DATA = {
  'Karnataka': {
    state: 'Karnataka',
    city: 'Bengaluru',
    discom: 'BESCOM (Bangalore Electricity Supply)',
    baseTariff: 7.20,
    peakTariff: 11.50, // 18:00 - 22:00
    solarGreenTariff: 4.60, // 10:00 - 15:00
    solarIrradiance: 5.4, // kWh/m²/day
    stateSolarSubsidy: 15000,
  },
  'Maharashtra': {
    state: 'Maharashtra',
    city: 'Mumbai',
    discom: 'Tata Power / Adani Electricity',
    baseTariff: 8.40,
    peakTariff: 13.20,
    solarGreenTariff: 5.20,
    solarIrradiance: 5.1,
    stateSolarSubsidy: 12000,
  },
  'Delhi': {
    state: 'Delhi',
    city: 'New Delhi',
    discom: 'BSES Rajdhani / Yamuna',
    baseTariff: 6.80,
    peakTariff: 10.90,
    solarGreenTariff: 4.20,
    solarIrradiance: 4.9,
    stateSolarSubsidy: 20000, // Delhi Solar Policy 2024 incentive
  },
  'Telangana': {
    state: 'Telangana',
    city: 'Hyderabad',
    discom: 'TSSPDCL (Southern Power)',
    baseTariff: 7.50,
    peakTariff: 11.80,
    solarGreenTariff: 4.80,
    solarIrradiance: 5.5,
    stateSolarSubsidy: 10000,
  },
  'Tamil Nadu': {
    state: 'Tamil Nadu',
    city: 'Chennai',
    discom: 'TANGEDCO',
    baseTariff: 7.10,
    peakTariff: 11.20,
    solarGreenTariff: 4.50,
    solarIrradiance: 5.3,
    stateSolarSubsidy: 14000,
  },
  'Gujarat': {
    state: 'Gujarat',
    city: 'Ahmedabad',
    discom: 'Torrent Power / GUVNL',
    baseTariff: 6.90,
    peakTariff: 10.50,
    solarGreenTariff: 4.40,
    solarIrradiance: 5.8,
    stateSolarSubsidy: 18000,
  }
};

// Default Home Setup Presets for Quick Testing in Setup Flow
export const HOME_PRESETS = {
  '2bhk': {
    name: '2BHK Urban Apartment',
    homeType: 'Apartment',
    roomsCount: 2,
    monthlyBill: 3400,
    airConditioners: [
      { id: 'ac-1', name: 'Master Bedroom AC', tonnage: 1.5, starRating: 3, ageYears: 4, hoursPerDay: 7, standbyWatts: 14, isSmartPlugged: false }
    ],
    refrigerators: [
      { id: 'ref-1', name: 'Kitchen Refrigerator', type: 'Single Door (190L)', starRating: 3, ageYears: 6, standbyWatts: 25, avgWatts: 140, healthScore: 78, isSmartPlugged: false }
    ],
    waterHeaters: [
      { id: 'wh-1', name: 'Bathroom Geyser', type: 'Storage Geyser (15L)', wattage: 2000, ageYears: 4, hoursPerDay: 1.2, standbyWatts: 22, isSmartPlugged: false }
    ],
    fansCount: 4,
    bldcFansCount: 0,
    cflTubesCount: 4,
    ledBulbsCount: 6,
    standbyDevices: [
      { id: 'sb-1', name: 'Smart TV & Set-Top Box (Standby)', watts: 18, location: 'Living Room', killed: false },
      { id: 'sb-2', name: 'Microwave Clock Display', watts: 6, location: 'Kitchen', killed: false },
      { id: 'sb-3', name: 'WiFi Router + Smart Hub', watts: 12, location: 'Hallway', killed: false }
    ]
  },
  '3bhk': {
    name: '3BHK Modern Family Home',
    homeType: 'Apartment',
    roomsCount: 3,
    monthlyBill: 6200,
    airConditioners: [
      { id: 'ac-1', name: 'Master Bed AC (1.5T 3-Star Non-Inverter)', tonnage: 1.5, starRating: 3, ageYears: 7, hoursPerDay: 8, standbyWatts: 16, isSmartPlugged: false },
      { id: 'ac-2', name: 'Kids Bedroom AC (1.0T 2-Star)', tonnage: 1.0, starRating: 2, ageYears: 5, hoursPerDay: 6, standbyWatts: 12, isSmartPlugged: false }
    ],
    refrigerators: [
      { id: 'ref-1', name: 'Double Door Frost-Free (320L)', type: 'Double Door Frost-Free', starRating: 2, ageYears: 8, standbyWatts: 38, avgWatts: 195, healthScore: 54, anomaly: 'Compressor thermal cycling 3.8x baseline; worn door magnetic gasket', isSmartPlugged: false }
    ],
    waterHeaters: [
      { id: 'wh-1', name: 'Master Bath Storage Geyser (25L)', type: 'Storage Geyser (25L)', wattage: 2000, ageYears: 6, hoursPerDay: 1.8, standbyWatts: 32, isSmartPlugged: false },
      { id: 'wh-2', name: 'Common Bath Instant Geyser (3L)', type: 'Instant Geyser (3L)', wattage: 3000, ageYears: 3, hoursPerDay: 0.8, standbyWatts: 8, isSmartPlugged: false }
    ],
    fansCount: 7,
    bldcFansCount: 1,
    cflTubesCount: 8,
    ledBulbsCount: 10,
    standbyDevices: [
      { id: 'sb-1', name: '55" OLED TV & Home Theater Standby', watts: 26, location: 'Living Room', killed: false },
      { id: 'sb-2', name: 'Gaming Console & Soundbar Standby', watts: 19, location: 'Den', killed: false },
      { id: 'sb-3', name: 'Microwave & Oven Standby Clocks', watts: 9, location: 'Kitchen', killed: false },
      { id: 'sb-4', name: 'RO Purifier Standby UV Lamp', watts: 14, location: 'Kitchen', killed: false },
      { id: 'sb-5', name: 'Dual Laptop Chargers left plugged', watts: 11, location: 'Study', killed: false }
    ]
  },
  'villa': {
    name: '4BHK Independent Villa',
    homeType: 'Villa / House',
    roomsCount: 4,
    monthlyBill: 12400,
    airConditioners: [
      { id: 'ac-1', name: 'Master Bed AC (2.0T 3-Star)', tonnage: 2.0, starRating: 3, ageYears: 6, hoursPerDay: 9, standbyWatts: 18, isSmartPlugged: false },
      { id: 'ac-2', name: 'Living Room Split AC (2.0T 2-Star)', tonnage: 2.0, starRating: 2, ageYears: 7, hoursPerDay: 6, standbyWatts: 18, isSmartPlugged: false },
      { id: 'ac-3', name: 'Guest Bed AC (1.5T 3-Star)', tonnage: 1.5, starRating: 3, ageYears: 4, hoursPerDay: 4, standbyWatts: 14, isSmartPlugged: false }
    ],
    refrigerators: [
      { id: 'ref-1', name: 'Side-by-Side Refrigerator (580L)', type: 'Side-by-Side Inverter', starRating: 3, ageYears: 7, standbyWatts: 42, avgWatts: 240, healthScore: 61, anomaly: 'Condenser coil dust coating causing +28% continuous power surge', isSmartPlugged: false }
    ],
    waterHeaters: [
      { id: 'wh-1', name: 'Master Suite 35L Storage Geyser', type: 'Storage Geyser (35L)', wattage: 2500, ageYears: 5, hoursPerDay: 2.2, standbyWatts: 40, isSmartPlugged: false },
      { id: 'wh-2', name: 'Floor 1 Storage Geyser (25L)', type: 'Storage Geyser (25L)', wattage: 2000, ageYears: 6, hoursPerDay: 1.5, standbyWatts: 30, isSmartPlugged: false }
    ],
    fansCount: 11,
    bldcFansCount: 2,
    cflTubesCount: 12,
    ledBulbsCount: 18,
    standbyDevices: [
      { id: 'sb-1', name: 'Media Room 75" TV + Amp Standby', watts: 38, location: 'Media Room', killed: false },
      { id: 'sb-2', name: 'Living Room TV & STB', watts: 22, location: 'Living Room', killed: false },
      { id: 'sb-3', name: 'Kitchen Built-in Microwave & Oven', watts: 16, location: 'Kitchen', killed: false },
      { id: 'sb-4', name: 'Pool Pump Standby Sensor', watts: 28, location: 'Outdoor', killed: false },
      { id: 'sb-5', name: 'Smart Home Hubs & Extenders', watts: 24, location: 'Whole House', killed: false }
    ]
  }
};

// Retrofit Catalog Options
export const RETROFIT_CATALOG = [
  {
    id: 'ac_upgrade',
    category: 'Cooling',
    title: '5-Star AI Inverter Dual-Rotary AC',
    currentTech: 'Old 2/3-Star Fixed Speed Compressor',
    newTech: '5-Star Inverter with Predictive Cooling',
    avgUnitCost: 42000,
    subsidyDiscount: 3500,
    annualEnergySavedKwh: 640,
    icon: 'Wind',
    description: 'BEE 5-Star inverter adjusts motor speed dynamically, eliminating high start-stop spikes and saving 45% power.'
  },
  {
    id: 'bldc_fan',
    category: 'Ventilation',
    title: 'Super-Efficient 28W BLDC Ceiling Fans',
    currentTech: 'Old 75W Induction Motor Fans',
    newTech: '28W Brushless DC Motor with Smart Remote',
    avgUnitCost: 2800,
    subsidyDiscount: 300,
    annualEnergySavedKwh: 145, // per fan
    icon: 'Fan',
    description: 'Consumes merely 28 Watts at top speed compared to 75-80W on old capacitor fans. Operates smoothly even on low inverter voltages.'
  },
  {
    id: 'led_conversion',
    category: 'Lighting',
    title: 'High-Efficacy 9W Smart LED Bulbs',
    currentTech: '40W Fluorescent Tubes & 60W Bulbs',
    newTech: '9W Lumens-Boost LED (110 lm/W)',
    avgUnitCost: 140,
    subsidyDiscount: 20,
    annualEnergySavedKwh: 68, // per light point
    icon: 'Lightbulb',
    description: 'Instant 80% reduction in lighting draw with zero flicker, 25,000 hour lifespan, and no toxic mercury vapour.'
  },
  {
    id: 'heatpump_geyser',
    category: 'Water Heating',
    title: 'Hybrid Heat Pump / 5-Star Digital Geyser',
    currentTech: 'Older Resistance Heating Element (2000W)',
    newTech: 'Thermodynamic Heat Pump or 5-Star Instant Tank',
    avgUnitCost: 18500,
    subsidyDiscount: 2000,
    annualEnergySavedKwh: 480,
    icon: 'Flame',
    description: 'Extracts heat from ambient air to warm water, slashing heating electricity consumption by up to 60%.'
  }
];

// Eco-Leaderboard Sample Community Members
export const ECO_LEADERBOARD = [
  { rank: 1, name: 'Sunita Mehra', locality: 'Indiranagar 4th Block', score: 96, monthlySavedKwh: 215, solarKwp: 4.5, badge: 'Solar Sovereign' },
  { rank: 2, name: 'Vikramaditya Rao', locality: 'Koramangala 6th Block', score: 92, monthlySavedKwh: 184, solarKwp: 3.2, badge: 'Phantom Slayer' },
  { rank: 3, name: 'Ananya Deshmukh', locality: 'HSR Layout Sector 2', score: 89, monthlySavedKwh: 162, solarKwp: 3.0, badge: 'Peak Shifter' },
  { rank: 4, name: 'You (Current User)', locality: 'Your Household', score: 71, monthlySavedKwh: 88, solarKwp: 0, badge: 'Eco Climber' },
  { rank: 5, name: 'Rajeev & Priya', locality: 'Whitefield Palm Meadows', score: 68, monthlySavedKwh: 75, solarKwp: 0, badge: 'Green Apprentice' },
  { rank: 6, name: 'Dr. K. Swaminathan', locality: 'Malleshwaram 15th Cross', score: 65, monthlySavedKwh: 62, solarKwp: 2.0, badge: 'Energy Scout' }
];

// Notification Alerts Feed
export const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif-1',
    type: 'peak_warning',
    title: 'DISCOM Peak Tariff Surge Alert',
    message: 'Evening peak window begins in 20 minutes (18:00 - 22:00). Current tariff rises from ₹7.20 to ₹11.50/kWh. Shift heavy geysers or EV charging now!',
    time: '5 mins ago',
    urgent: true
  },
  {
    id: 'notif-2',
    type: 'vampire_detected',
    title: 'Phantom Baseline Surge Detected',
    message: 'Night-time standby draw was 138W (nominal is <35W). Kitchen refrigerator compressor short-cycling flagged for checkup.',
    time: '2 hours ago',
    urgent: false
  },
  {
    id: 'notif-3',
    type: 'solar_opportunity',
    title: 'PM Surya Ghar Yojana Matching Ready',
    message: 'Based on your ₹5,800/mo bill, your rooftop qualifies for up to ₹78,000 in direct central subsidy + ₹15,000 state incentive.',
    time: 'Today',
    urgent: false
  }
];
