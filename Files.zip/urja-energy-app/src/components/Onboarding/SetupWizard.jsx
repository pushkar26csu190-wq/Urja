import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { REGIONAL_DATA, HOME_PRESETS } from '../../data/mockData';
import { 
  MapPin, 
  Home, 
  Wind, 
  Refrigerator, 
  Flame, 
  Lightbulb, 
  Zap, 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  ShieldCheck, 
  Plus, 
  Minus, 
  Trash2, 
  Cpu, 
  Activity, 
  ArrowRight 
} from 'lucide-react';

export const SetupWizard = () => {
  const { 
    userProfile, 
    setUserProfile, 
    inventory, 
    setInventory, 
    applyPreset, 
    setActiveView,
    triggerConfetti,
    vampireCalculations,
    solarCalculations,
    loadShiftCalculations,
    retrofitCalculations,
    ecoScore
  } = useEnergy();

  const [step, setStep] = useState(1);
  const [isCalibrating, setIsCalibrating] = useState(false);

  // Local form states
  const [stateName, setStateName] = useState(userProfile?.state || 'Karnataka');
  const [cityArea, setCityArea] = useState(userProfile?.city || 'Indiranagar, Bengaluru');
  const [homeType, setHomeType] = useState(userProfile?.homeType || 'Apartment (3BHK)');
  const [roomsCount, setRoomsCount] = useState(userProfile?.roomsCount || 3);
  const [monthlyBill, setMonthlyBill] = useState(userProfile?.monthlyBill || 6200);
  const [hasRooftopAccess, setHasRooftopAccess] = useState(userProfile?.hasRooftopAccess ?? true);

  // Appliances state with safe initial arrays
  const [acs, setAcs] = useState(inventory?.airConditioners || []);
  const [fridges, setFridges] = useState(inventory?.refrigerators || []);
  const [geysers, setGeysers] = useState(inventory?.waterHeaters || []);
  const [fansCount, setFansCount] = useState(inventory?.fansCount || 6);
  const [bldcFansCount, setBldcFansCount] = useState(inventory?.bldcFansCount || 1);
  const [cflCount, setCflCount] = useState(inventory?.cflTubesCount || 6);
  const [ledCount, setLedCount] = useState(inventory?.ledBulbsCount || 10);

  const regionInfo = REGIONAL_DATA[stateName] || REGIONAL_DATA['Karnataka'];

  // Add new AC
  const handleAddAc = () => {
    if (acs.length >= 6) return;
    const newAc = {
      id: `ac-${Date.now()}`,
      name: `Bedroom ${acs.length + 1} AC`,
      tonnage: 1.5,
      starRating: 3,
      ageYears: 4,
      hoursPerDay: 7,
      standbyWatts: 14,
      isSmartPlugged: false
    };
    setAcs(prev => [...prev, newAc]);
  };

  const handleRemoveAc = (id) => {
    setAcs(prev => prev.filter(a => a.id !== id));
  };

  const updateAc = (id, field, value) => {
    setAcs(prev => prev.map(a => a.id === id ? { ...a, [field]: value } : a));
  };

  // Add Refrigerator
  const handleAddFridge = () => {
    if (fridges.length >= 4) return;
    const newRf = {
      id: `ref-${Date.now()}`,
      name: `Refrigerator ${fridges.length + 1}`,
      type: 'Single Door (190L)',
      starRating: 3,
      ageYears: 5,
      standbyWatts: 25,
      avgWatts: 150,
      healthScore: 75,
      isSmartPlugged: false
    };
    setFridges(prev => [...prev, newRf]);
  };

  const handleRemoveFridge = (id) => {
    setFridges(prev => prev.filter(f => f.id !== id));
  };

  const updateFridge = (id, field, value) => {
    setFridges(prev => prev.map(f => f.id === id ? { ...f, [field]: value } : f));
  };

  // Add Geyser
  const handleAddGeyser = () => {
    if (geysers.length >= 4) return;
    const newWh = {
      id: `wh-${Date.now()}`,
      name: `Bathroom ${geysers.length + 1} Geyser`,
      type: 'Storage Geyser (15L)',
      wattage: 2000,
      ageYears: 4,
      hoursPerDay: 1.5,
      standbyWatts: 24,
      isSmartPlugged: false
    };
    setGeysers(prev => [...prev, newWh]);
  };

  const handleRemoveGeyser = (id) => {
    setGeysers(prev => prev.filter(g => g.id !== id));
  };

  const updateGeyser = (id, field, value) => {
    setGeysers(prev => prev.map(g => g.id === id ? { ...g, [field]: value } : g));
  };

  // Apply one of the quick presets
  const handleQuickPreset = (key) => {
    applyPreset(key);
    const p = HOME_PRESETS[key];
    if (p) {
      setHomeType(p.homeType || 'Apartment');
      setRoomsCount(p.roomsCount || 3);
      setMonthlyBill(p.monthlyBill || 5000);
      setAcs(p.airConditioners || []);
      setFridges(p.refrigerators || []);
      setGeysers(p.waterHeaters || []);
      setFansCount(p.fansCount || 5);
      setBldcFansCount(p.bldcFansCount || 0);
      setCflCount(p.cflTubesCount || 4);
      setLedCount(p.ledBulbsCount || 8);
    }
  };

  // Final Calibration Step - Rock Solid Execution
  const runAiCalibration = () => {
    setIsCalibrating(true);
    setStep(5);

    // Persist to context safely
    setUserProfile(prev => ({
      ...prev,
      state: stateName,
      city: cityArea || 'Bengaluru',
      homeType,
      roomsCount: Number(roomsCount) || 3,
      monthlyBill: Number(monthlyBill) || 5000,
      hasRooftopAccess: Boolean(hasRooftopAccess)
    }));

    setInventory(prev => ({
      ...prev,
      airConditioners: acs,
      refrigerators: fridges,
      waterHeaters: geysers,
      fansCount: Number(fansCount) || 5,
      bldcFansCount: Number(bldcFansCount) || 1,
      cflTubesCount: Number(cflCount) || 4,
      ledBulbsCount: Number(ledCount) || 8
    }));

    setTimeout(() => {
      setIsCalibrating(false);
      triggerConfetti();
    }, 1200);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      
      {/* Onboarding Header Banner */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-urja-navy-800 border border-urja-lime-500/40 text-xs font-bold text-urja-lime-400 mb-3 shadow-glow-lime">
          <Cpu className="w-3.5 h-3.5 text-urja-lime-400" />
          <span>Interactive Neural Onboarding & Household Calibration</span>
        </div>
        
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Calibrate Your <span className="text-gradient-urja">URJA AI Engine</span>
        </h1>
        <p className="mt-2 text-sm text-slate-400 max-w-xl mx-auto">
          Specify your exact appliance inventory and locality. URJA will dynamically customize all downstream models, financial calculations, and grid synchronizations.
        </p>

        {/* Quick Presets Bar */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs font-semibold text-slate-400 mr-1">
            Quick Architecture Presets:
          </span>
          <button
            onClick={() => handleQuickPreset('2bhk')}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:border-urja-cyan-400 hover:text-urja-cyan-300 transition-all"
          >
            🏢 2BHK Urban Flat
          </button>
          <button
            onClick={() => handleQuickPreset('3bhk')}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-urja-navy-800 border border-urja-lime-500/50 text-urja-lime-400 shadow-glow-lime transition-all"
          >
            🏡 3BHK Family Home (Optimal)
          </button>
          <button
            onClick={() => handleQuickPreset('villa')}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:border-urja-cyan-400 hover:text-urja-cyan-300 transition-all"
          >
            🏰 4BHK Villa
          </button>
        </div>
      </div>

      {/* Step Indicators */}
      <div className="flex items-center justify-between mb-8 max-w-2xl mx-auto px-4">
        {[
          { num: 1, label: 'Grid & Location' },
          { num: 2, label: 'Dwelling & Bill' },
          { num: 3, label: 'Cooling & Heating' },
          { num: 4, label: 'Appliances & Standby' },
          { num: 5, label: 'Neural Calibration' },
        ].map((s) => (
          <div key={s.num} className="flex flex-col items-center">
            <div 
              className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-extrabold transition-all ${
                step === s.num
                  ? 'bg-urja-lime-500 text-urja-navy-950 ring-4 ring-urja-lime-500/20 scale-105 shadow-glow-lime'
                  : step > s.num
                  ? 'bg-urja-navy-750 text-urja-cyan-300 border border-urja-cyan-400/40'
                  : 'bg-urja-navy-850 text-slate-500 border border-urja-navy-700'
              }`}
            >
              {step > s.num ? <CheckCircle2 className="w-5 h-5 text-urja-lime-400" /> : s.num}
            </div>
            <span className="hidden sm:block text-[11px] font-medium text-slate-400 mt-1.5">
              {s.label}
            </span>
          </div>
        ))}
      </div>

      {/* Main Wizard Form Card */}
      <div className="cyber-card rounded-3xl p-6 sm:p-8 shadow-cyber">
        
        {/* STEP 1: Locality & DISCOM */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-urja-navy-700">
              <div className="w-10 h-10 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Select Region & DISCOM Grid Profile</h2>
                <p className="text-xs text-slate-400">Auto-fetches Time-of-Day (ToD) tariff slabs and regional solar irradiance.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  State / Grid Jurisdiction
                </label>
                <select
                  value={stateName}
                  onChange={(e) => setStateName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white text-sm focus:outline-none focus:border-urja-cyan-400"
                >
                  {Object.keys(REGIONAL_DATA).map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Locality / City Area
                </label>
                <input
                  type="text"
                  value={cityArea}
                  onChange={(e) => setCityArea(e.target.value)}
                  placeholder="e.g. Indiranagar, Bengaluru"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white text-sm focus:outline-none focus:border-urja-cyan-400"
                />
              </div>
            </div>

            {/* Grid Utility Stats */}
            <div className="p-4 rounded-2xl bg-urja-navy-900/90 border border-urja-navy-700 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-urja-cyan-400">
                  Detected Grid Utility Profile
                </span>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-urja-cyan-400/10 text-urja-cyan-300 border border-urja-cyan-400/30">
                  {regionInfo.discom}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700">
                  <div className="text-[10px] text-slate-400">Base Unit Rate</div>
                  <div className="text-sm font-extrabold text-white">₹{regionInfo.baseTariff}/kWh</div>
                </div>
                <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-900/40">
                  <div className="text-[10px] text-rose-400">Peak Surge Rate</div>
                  <div className="text-sm font-extrabold text-rose-400">₹{regionInfo.peakTariff}/kWh</div>
                </div>
                <div className="p-2.5 rounded-xl bg-urja-lime-500/10 border border-urja-lime-500/30">
                  <div className="text-[10px] text-urja-lime-400">Solar Green Tariff</div>
                  <div className="text-sm font-extrabold text-urja-lime-400">₹{regionInfo.solarGreenTariff}/kWh</div>
                </div>
                <div className="p-2.5 rounded-xl bg-urja-cyan-400/10 border border-urja-cyan-400/30">
                  <div className="text-[10px] text-urja-cyan-400">Solar Irradiance</div>
                  <div className="text-sm font-extrabold text-urja-cyan-300">{regionInfo.solarIrradiance} kWh/m²</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Home Scale & Energy Bill */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-urja-navy-700">
              <div className="w-10 h-10 rounded-2xl bg-urja-lime-400/10 border border-urja-lime-400/30 flex items-center justify-center text-urja-lime-400">
                <Home className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Dwelling Type & Typical Monthly Bill</h2>
                <p className="text-xs text-slate-400">Establishes baseline power consumption (kWh) and peak threshold.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Dwelling Type
                </label>
                <select
                  value={homeType}
                  onChange={(e) => setHomeType(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white text-sm focus:outline-none focus:border-urja-lime-400"
                >
                  <option value="Apartment (1BHK / Studio)">Apartment (1BHK / Studio)</option>
                  <option value="Apartment (2BHK)">Apartment (2BHK)</option>
                  <option value="Apartment (3BHK)">Apartment (3BHK)</option>
                  <option value="Apartment (4BHK+)">Apartment (4BHK+)</option>
                  <option value="Independent House / Villa">Independent House / Villa</option>
                  <option value="Duplex Rowhouse">Duplex Rowhouse</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Number of Active Rooms: <span className="text-urja-lime-400 font-extrabold">{roomsCount} Rooms</span>
                </label>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setRoomsCount(Math.max(1, roomsCount - 1))}
                    className="p-2.5 rounded-xl border border-urja-navy-700 hover:bg-urja-navy-800 text-white"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="flex-1 text-center font-bold text-white text-sm">
                    {roomsCount} {roomsCount === 1 ? 'Room' : 'Rooms'}
                  </div>
                  <button 
                    onClick={() => setRoomsCount(Math.min(8, roomsCount + 1))}
                    className="p-2.5 rounded-xl border border-urja-navy-700 hover:bg-urja-navy-800 text-white"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Bill Slider */}
            <div className="p-5 rounded-2xl bg-urja-navy-900/90 border border-urja-navy-700 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">
                  Average Monthly Electricity Bill
                </span>
                <span className="text-xl font-black text-urja-lime-400">
                  ₹{(Number(monthlyBill) || 0).toLocaleString()} / month
                </span>
              </div>
              <input
                type="range"
                min="1200"
                max="25000"
                step="200"
                value={monthlyBill}
                onChange={(e) => setMonthlyBill(Number(e.target.value))}
                className="w-full accent-[#B7F34A] h-2 bg-urja-navy-750 rounded-lg cursor-pointer"
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>₹1,200</span>
                <span>₹10,000</span>
                <span>₹25,000+</span>
              </div>

              <div className="pt-2 border-t border-urja-navy-750 flex items-center justify-between text-xs text-slate-400">
                <span>Estimated Energy Volume:</span>
                <span className="font-bold text-urja-cyan-300">
                  ~{Math.round(monthlyBill / (regionInfo.baseTariff || 1))} kWh / month (~{(monthlyBill / (regionInfo.baseTariff || 1) / 30).toFixed(1)} kWh/day)
                </span>
              </div>
            </div>

            {/* Rooftop Access */}
            <div className="flex items-center justify-between p-4 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/60">
              <div>
                <div className="text-xs font-bold text-white">Private or Society Rooftop Access</div>
                <div className="text-[11px] text-slate-400">Required for PM Surya Ghar rooftop solar system installation</div>
              </div>
              <button
                onClick={() => setHasRooftopAccess(!hasRooftopAccess)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  hasRooftopAccess 
                    ? 'bg-urja-lime-500 text-urja-navy-950 font-extrabold shadow-glow-lime' 
                    : 'bg-urja-navy-800 text-slate-400 border border-urja-navy-700'
                }`}
              >
                {hasRooftopAccess ? '✓ Rooftop Available' : 'No Rooftop Access'}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Heavy Cooling & Heating */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-urja-navy-700">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400">
                  <Wind className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Air Conditioners & Water Heaters</h2>
                  <p className="text-xs text-slate-400">High-draw thermal appliances account for ~65% of monthly consumption.</p>
                </div>
              </div>
              <button
                onClick={handleAddAc}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-urja-cyan-400/20 text-urja-cyan-300 border border-urja-cyan-400/40 hover:bg-urja-cyan-400/30 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add AC</span>
              </button>
            </div>

            <div className="space-y-3">
              {acs.map((ac) => (
                <div key={ac.id} className="p-3.5 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/90 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-2">
                      <Wind className="w-4 h-4 text-urja-cyan-400" />
                      {ac.name}
                    </span>
                    <button onClick={() => handleRemoveAc(ac.id)} className="text-slate-400 hover:text-rose-400 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Tonnage</span>
                      <select
                        value={ac.tonnage}
                        onChange={(e) => updateAc(ac.id, 'tonnage', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white font-semibold"
                      >
                        <option value={1.0}>1.0 Ton</option>
                        <option value={1.5}>1.5 Ton</option>
                        <option value={2.0}>2.0 Ton</option>
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">BEE Rating</span>
                      <select
                        value={ac.starRating}
                        onChange={(e) => updateAc(ac.id, 'starRating', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white font-semibold"
                      >
                        <option value={1}>1-Star (Heavy Draw)</option>
                        <option value={2}>2-Star</option>
                        <option value={3}>3-Star (Standard)</option>
                        <option value={4}>4-Star</option>
                        <option value={5}>5-Star Inverter</option>
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Age</span>
                      <select
                        value={ac.ageYears}
                        onChange={(e) => updateAc(ac.id, 'ageYears', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white font-semibold"
                      >
                        <option value={2}>1 - 2 Years</option>
                        <option value={4}>3 - 5 Years</option>
                        <option value={7}>6 - 8 Years (High Standby)</option>
                        <option value={10}>9+ Years (Critical)</option>
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Daily Run</span>
                      <select
                        value={ac.hoursPerDay}
                        onChange={(e) => updateAc(ac.id, 'hoursPerDay', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white font-semibold"
                      >
                        <option value={4}>~4 Hours/day</option>
                        <option value={7}>~7 Hours/day</option>
                        <option value={10}>~10 Hours/day</option>
                        <option value={14}>~14+ Hours/day</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Geysers */}
            <div className="pt-4 border-t border-urja-navy-750 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Water Heaters / Geysers ({geysers.length})
                </div>
                <button
                  onClick={handleAddGeyser}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Geyser</span>
                </button>
              </div>

              {geysers.map((wh) => (
                <div key={wh.id} className="p-3 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/90 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    <Flame className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-bold text-white">{wh.name}</div>
                      <div className="text-[10px] text-slate-400">{wh.wattage}W • {wh.type}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={wh.wattage}
                      onChange={(e) => updateGeyser(wh.id, 'wattage', Number(e.target.value))}
                      className="p-1.5 rounded-lg border border-urja-navy-700 bg-urja-navy-800 text-white text-xs"
                    >
                      <option value={2000}>2000 Watts</option>
                      <option value={3000}>3000 Watts</option>
                    </select>
                    <button onClick={() => handleRemoveGeyser(wh.id)} className="text-slate-400 hover:text-rose-400 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 4: Refrigeration, Lighting & Phantom Draws */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-urja-navy-700">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-urja-lime-400/10 border border-urja-lime-400/30 flex items-center justify-center text-urja-lime-400">
                  <Refrigerator className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Refrigeration & Ventilation Lighting</h2>
                  <p className="text-xs text-slate-400">Enables detection of compressor seal anomalies and continuous vampire load.</p>
                </div>
              </div>
            </div>

            {/* Refrigerator */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Primary Refrigerator
                </span>
                <button
                  onClick={handleAddFridge}
                  className="text-xs font-semibold text-urja-lime-400 hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Second Unit</span>
                </button>
              </div>

              {fridges.map((rf) => (
                <div key={rf.id} className="p-3.5 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/90 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-2">
                      <Refrigerator className="w-4 h-4 text-urja-lime-400" />
                      {rf.name}
                    </span>
                    {fridges.length > 1 && (
                      <button onClick={() => handleRemoveFridge(rf.id)} className="text-slate-400 hover:text-rose-400">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Configuration</span>
                      <select
                        value={rf.type}
                        onChange={(e) => updateFridge(rf.id, 'type', e.target.value)}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white"
                      >
                        <option value="Single Door (190L)">Single Door (190L)</option>
                        <option value="Double Door Frost-Free (320L)">Double Door Frost-Free (320L)</option>
                        <option value="Side-by-Side Inverter (550L)">Side-by-Side Inverter (550L)</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Appliance Age</span>
                      <select
                        value={rf.ageYears}
                        onChange={(e) => updateFridge(rf.id, 'ageYears', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white"
                      >
                        <option value={2}>Under 3 years (Healthy)</option>
                        <option value={5}>4 - 6 years</option>
                        <option value={8}>7 - 9 years (Compressor Wear Alert)</option>
                        <option value={12}>10+ years (Critical Degradation)</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">BEE Rating</span>
                      <select
                        value={rf.starRating}
                        onChange={(e) => updateFridge(rf.id, 'starRating', Number(e.target.value))}
                        className="w-full p-2 rounded-xl border border-urja-navy-700 bg-urja-navy-800 text-white"
                      >
                        <option value={1}>1-Star</option>
                        <option value={2}>2-Star</option>
                        <option value={3}>3-Star</option>
                        <option value={4}>4-Star</option>
                        <option value={5}>5-Star Inverter</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Fans & Lights */}
            <div className="pt-4 border-t border-urja-navy-750 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/60">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white">Ceiling Fans Total</span>
                  <span className="text-sm font-extrabold text-urja-lime-400">{fansCount} Fans</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="12"
                  value={fansCount}
                  onChange={(e) => setFansCount(Number(e.target.value))}
                  className="w-full accent-[#B7F34A] h-1.5 bg-urja-navy-750 rounded-lg cursor-pointer"
                />
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400">How many are 28W BLDC?</span>
                  <select
                    value={bldcFansCount}
                    onChange={(e) => setBldcFansCount(Number(e.target.value))}
                    className="p-1.5 rounded-lg border border-urja-navy-700 bg-urja-navy-800 text-white text-xs font-semibold"
                  >
                    {[...Array(fansCount + 1).keys()].map(n => (
                      <option key={n} value={n}>{n} BLDC</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl border border-urja-navy-700 bg-urja-navy-900/60">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white">Lighting Inventory</span>
                  <span className="text-xs text-urja-cyan-300">{cflCount} CFLs • {ledCount} LEDs</span>
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Older CFL / Tubes (40W):</span>
                    <input
                      type="number"
                      min="0"
                      max="20"
                      value={cflCount}
                      onChange={(e) => setCflCount(Number(e.target.value))}
                      className="w-16 p-1.5 rounded-lg border border-urja-navy-700 bg-urja-navy-800 text-white text-center font-bold"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Modern LEDs (9W):</span>
                    <input
                      type="number"
                      min="0"
                      max="40"
                      value={ledCount}
                      onChange={(e) => setLedCount(Number(e.target.value))}
                      className="w-16 p-1.5 rounded-lg border border-urja-navy-700 bg-urja-navy-800 text-white text-center font-bold"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: AI Neural Calibration & Dynamic Snapshot */}
        {step === 5 && (
          <div className="py-6 space-y-6">
            {isCalibrating ? (
              <div className="text-center py-12 space-y-5">
                <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-urja-lime-400 border-t-transparent animate-spin"></div>
                  <div className="w-14 h-14 rounded-2xl bg-urja-navy-800 border border-urja-cyan-400/50 flex items-center justify-center text-urja-cyan-400 shadow-glow-cyan">
                    <Cpu className="w-7 h-7" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-extrabold text-white">
                    URJA Neural Calibration Active
                  </h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                    Matching {acs.length} AC compressor signatures, idle standby baselines, and local {regionInfo?.discom || 'Grid'} tariffs...
                  </p>
                </div>
                <div className="w-56 h-1.5 bg-urja-navy-800 rounded-full mx-auto overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-r from-urja-lime-400 to-urja-cyan-400 animate-pulse"></div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-urja-lime-500/20 text-urja-lime-300 border border-urja-lime-500/40 text-xs font-bold mb-2">
                    <CheckCircle2 className="w-4 h-4 text-urja-lime-400" />
                    <span>Neural Calibration Complete & Synced!</span>
                  </div>
                  <h2 className="text-2xl font-extrabold text-white">
                    Personalized Energy Footprint Matrix
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Configured for your {roomsCount}-room {homeType} in {cityArea || 'Bengaluru'}:
                  </p>
                </div>

                {/* 4 Pillars Immediate Impact Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Pillar 1 */}
                  <div className="p-4 rounded-2xl border border-rose-500/30 bg-rose-950/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400">
                        Pillar 1: Vampire Load
                      </span>
                      <span className="text-xs font-bold text-rose-400">
                        {vampireCalculations?.currentVampireWatts || 120}W Continuous
                      </span>
                    </div>
                    <div className="text-2xl font-black text-rose-400">
                      ₹{(vampireCalculations?.monthlyFinancialWaste || 780).toLocaleString()} / month
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Accounts for ~{vampireCalculations?.billPercentage || 12}% of your monthly electricity bill.
                    </p>
                  </div>

                  {/* Pillar 2 */}
                  <div className="p-4 rounded-2xl border border-urja-lime-500/30 bg-urja-lime-500/10">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-urja-lime-400">
                        Pillar 2: Retrofit Potential
                      </span>
                      <span className="text-xs font-bold text-urja-lime-400">
                        {retrofitCalculations?.paybackYears || '2.1'} Yrs Payback
                      </span>
                    </div>
                    <div className="text-2xl font-black text-urja-lime-400">
                      ₹{(retrofitCalculations?.monthlyMoneySaved || 1850).toLocaleString()} / month
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Upgrading to 5-star BEE and BLDC fans creates ₹{(retrofitCalculations?.tenYearNetReturn || 85000).toLocaleString()} wealth.
                    </p>
                  </div>

                  {/* Pillar 3 */}
                  <div className="p-4 rounded-2xl border border-urja-cyan-400/30 bg-urja-cyan-400/10">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-urja-cyan-400">
                        Pillar 3: Peak Load Shift
                      </span>
                      <span className="text-xs font-bold text-urja-cyan-300">
                        ₹{loadShiftCalculations?.tariffDiff || '6.90'} Delta
                      </span>
                    </div>
                    <div className="text-2xl font-black text-urja-cyan-300">
                      Save ₹{(loadShiftCalculations?.potentialMaxSavingsRupees || 890).toLocaleString()} / mo
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Shifting morning heating & laundry to 10:00 - 15:00 solar hours.
                    </p>
                  </div>

                  {/* Pillar 4 */}
                  <div className="p-4 rounded-2xl border border-amber-500/30 bg-amber-500/10">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
                        Pillar 4: PM Surya Ghar
                      </span>
                      <span className="text-xs font-bold text-amber-400">
                        {solarCalculations?.recommendedCapacityKw || 3} kW System
                      </span>
                    </div>
                    <div className="text-2xl font-black text-amber-400">
                      ₹{(solarCalculations?.totalSubsidy || 78000).toLocaleString()} Grant
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Direct Central & State subsidy with positive cashflow on Day 1.
                    </p>
                  </div>

                </div>

                {/* Big Launch CTA */}
                <div className="pt-4 text-center">
                  <button
                    onClick={() => setActiveView('home')}
                    className="w-full sm:w-auto px-8 py-3.5 rounded-2xl font-black text-sm bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all hover:scale-105 active:scale-95"
                  >
                    Enter URJA Operating Dashboard →
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Wizard Navigation Buttons (Steps 1 to 4) */}
        {step < 5 && (
          <div className="mt-8 pt-4 border-t border-urja-navy-750 flex items-center justify-between">
            {step > 1 ? (
              <button
                onClick={() => setStep(step - 1)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-300 hover:bg-urja-navy-800 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            ) : (
              <button
                onClick={() => setActiveView('home')}
                className="text-xs font-semibold text-slate-400 hover:text-white"
              >
                Skip to Home
              </button>
            )}

            {step < 4 ? (
              <button
                onClick={() => setStep(step + 1)}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold bg-urja-cyan-400 hover:bg-urja-cyan-300 text-urja-navy-950 shadow-glow-cyan transition-all hover:scale-105"
              >
                <span>Continue to Step {step + 1}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={runAiCalibration}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-extrabold bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all hover:scale-105"
              >
                <Sparkles className="w-4 h-4" />
                <span>Run AI Neural Calibration</span>
              </button>
            )}
          </div>
        )}

      </div>

    </div>
  );
};
