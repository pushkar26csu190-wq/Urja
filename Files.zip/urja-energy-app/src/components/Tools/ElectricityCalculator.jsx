import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Calculator, 
  Plus, 
  Trash2, 
  Zap, 
  ArrowLeft, 
  Sparkles, 
  Coins, 
  CheckCircle2, 
  TrendingDown, 
  Lightbulb,
  Wind,
  Flame,
  Refrigerator,
  Tv,
  Car
} from 'lucide-react';

export const ElectricityCalculator = () => {
  const { regionConfig, userProfile, setActiveView, triggerConfetti } = useEnergy();
  const tariffRate = Number(regionConfig?.baseTariff || 7.20);

  const [appliances, setAppliances] = useState([
    { id: 1, name: '1.5 Ton Split AC', watts: 1450, hoursPerDay: 7, qty: 1, daysPerMonth: 30, icon: 'Wind' },
    { id: 2, name: 'Double Door Refrigerator', watts: 180, hoursPerDay: 24, qty: 1, daysPerMonth: 30, icon: 'Refrigerator' },
    { id: 3, name: 'Storage Geyser (25L)', watts: 2000, hoursPerDay: 1.5, qty: 1, daysPerMonth: 30, icon: 'Flame' },
    { id: 4, name: 'Ceiling Fans (Traditional)', watts: 75, hoursPerDay: 12, qty: 4, daysPerMonth: 30, icon: 'Wind' },
    { id: 5, name: 'Smart TV & Soundbar', watts: 120, hoursPerDay: 5, qty: 1, daysPerMonth: 30, icon: 'Tv' },
    { id: 6, name: 'LED Lights (9W)', watts: 9, hoursPerDay: 6, qty: 8, daysPerMonth: 30, icon: 'Lightbulb' },
  ]);

  const [customName, setCustomName] = useState('');
  const [customWatts, setCustomWatts] = useState(100);
  const [customHours, setCustomHours] = useState(4);
  const [customQty, setCustomQty] = useState(1);

  const handleAddCustom = (e) => {
    e.preventDefault();
    if (!customName.trim()) return;
    const newItem = {
      id: Date.now(),
      name: customName,
      watts: Number(customWatts) || 100,
      hoursPerDay: Number(customHours) || 1,
      qty: Number(customQty) || 1,
      daysPerMonth: 30,
      icon: 'Zap'
    };
    setAppliances([...appliances, newItem]);
    setCustomName('');
    setCustomWatts(100);
    triggerConfetti();
  };

  const handleRemove = (id) => {
    setAppliances(appliances.filter(a => a.id !== id));
  };

  const handleUpdate = (id, field, value) => {
    setAppliances(appliances.map(a => a.id === id ? { ...a, [field]: Number(value) } : a));
  };

  // Calculations
  const calculations = appliances.map(app => {
    const dailyKwh = (app.watts * app.hoursPerDay * app.qty) / 1000;
    const monthlyKwh = dailyKwh * app.daysPerMonth;
    const monthlyCost = monthlyKwh * tariffRate;
    return {
      ...app,
      dailyKwh: dailyKwh.toFixed(2),
      monthlyKwh: Math.round(monthlyKwh),
      monthlyCost: Math.round(monthlyCost)
    };
  });

  const totalMonthlyKwh = calculations.reduce((acc, c) => acc + c.monthlyKwh, 0);
  const totalMonthlyCost = calculations.reduce((acc, c) => acc + c.monthlyCost, 0);
  const totalDailyKwh = (totalMonthlyKwh / 30).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-urja-lime-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-urja-lime-500/10 border border-urja-lime-500/30 flex items-center justify-center text-urja-lime-400 shadow-glow-lime">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-urja-lime-500/20 text-urja-lime-300 border border-urja-lime-500/40">
                  Interactive Tool
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Working Household Electricity Calculator
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Calculate precise unit draws and monthly bills calibrated to {regionConfig.discom} (₹{tariffRate}/kWh).
              </p>
            </div>
          </div>
        </div>

        {/* Total Cost Highlight Pill */}
        <div className="p-4 rounded-2xl bg-urja-navy-800 border border-urja-lime-500/40 shadow-glow-lime text-right">
          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Calculated Total Monthly Bill</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-lime-400">
            ₹{totalMonthlyCost.toLocaleString()}
            <span className="text-xs font-semibold text-slate-400 ml-1">/mo ({totalMonthlyKwh} kWh)</span>
          </div>
        </div>
      </div>

      {/* Appliance Inputs & Calculations Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Table & List (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="cyber-card rounded-3xl p-5 sm:p-6 shadow-cyber space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">
                Active Appliance Consumption Matrix
              </h3>
              <span className="text-xs text-slate-400">{appliances.length} items logged</span>
            </div>

            <div className="space-y-3">
              {calculations.map((app) => (
                <div 
                  key={app.id}
                  className="p-3.5 rounded-2xl bg-urja-navy-900 border border-urja-navy-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-urja-navy-800 border border-urja-navy-700 flex items-center justify-center text-urja-cyan-300">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-white">{app.name}</div>
                      <div className="text-[11px] text-slate-400">
                        {app.watts} Watts • Qty: {app.qty}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Daily Hours</span>
                      <input
                        type="number"
                        min="0.5"
                        max="24"
                        step="0.5"
                        value={app.hoursPerDay}
                        onChange={(e) => handleUpdate(app.id, 'hoursPerDay', e.target.value)}
                        className="w-16 p-1.5 rounded-lg border border-urja-navy-700 bg-urja-navy-800 text-white font-bold text-center"
                      />
                    </div>

                    <div className="text-right min-w-[90px]">
                      <span className="text-[10px] text-slate-400 block">Monthly Units</span>
                      <span className="font-bold text-urja-cyan-300">{app.monthlyKwh} kWh</span>
                    </div>

                    <div className="text-right min-w-[90px]">
                      <span className="text-[10px] text-slate-400 block">Monthly Cost</span>
                      <span className="font-black text-urja-lime-400">₹{app.monthlyCost.toLocaleString()}</span>
                    </div>

                    <button 
                      onClick={() => handleRemove(app.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-urja-navy-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Add Appliance Form & Tips (1 col) */}
        <div className="space-y-4">
          <div className="cyber-card rounded-3xl p-5 sm:p-6 shadow-cyber space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-urja-lime-400" />
              <span>Add Any Device / Appliance</span>
            </h3>

            <form onSubmit={handleAddCustom} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Appliance Name</label>
                <input
                  type="text"
                  placeholder="e.g. Induction Cooktop, Desktop PC"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Wattage (Watts)</label>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={customWatts}
                    onChange={(e) => setCustomWatts(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Run Hours / Day</label>
                  <input
                    type="number"
                    min="0.5"
                    max="24"
                    step="0.5"
                    value={customHours}
                    onChange={(e) => setCustomHours(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl font-extrabold text-xs bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all mt-2"
              >
                + Add To Calculation
              </button>
            </form>
          </div>

          {/* Quick AI Tip */}
          <div className="p-4 rounded-3xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold text-urja-cyan-300">
              <Sparkles className="w-4 h-4" />
              <span>URJA Optimization Insight</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Top power consumer in your list: <strong>{calculations[0]?.name}</strong> accounting for ₹{calculations[0]?.monthlyCost?.toLocaleString()}/mo. Shifting or retrofitting this device delivers the highest financial yield.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
