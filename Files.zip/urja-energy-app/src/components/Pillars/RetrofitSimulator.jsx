import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { RETROFIT_CATALOG } from '../../data/mockData';
import { 
  TrendingUp, 
  Leaf, 
  Wind, 
  Lightbulb, 
  Flame, 
  CheckCircle2, 
  ArrowLeft, 
  Download,
  Menu
} from 'lucide-react';

export const RetrofitSimulator = () => {
  const { 
    retrofitCalculations, 
    selectedRetrofits, 
    toggleRetrofit, 
    inventory, 
    userProfile, 
    regionConfig, 
    setActiveView,
    setIsNavPanelOpen,
    triggerConfetti 
  } = useEnergy();

  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadReport = () => {
    setDownloadSuccess(true);
    triggerConfetti();
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const iconsMap = {
    Wind: Wind,
    Fan: Wind,
    Lightbulb: Lightbulb,
    Flame: Flame
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-urja-lime-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-urja-lime-500/10 border border-urja-lime-500/30 flex items-center justify-center text-urja-lime-400 shadow-md">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-urja-lime-500/20 text-urja-lime-300 border border-urja-lime-500/40">
                  Pillar 2
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Dynamic "Retrofit ROI" Simulator
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Calibrated against {inventory?.airConditioners?.length || 2} ACs, {inventory?.fansCount || 6} fans, and {inventory?.cflTubesCount || 6} older points.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNavPanelOpen(true)}
            className="p-2.5 rounded-xl bg-urja-navy-800 border border-urja-navy-700 text-slate-300 hover:text-white"
            title="3-Line Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          <button
            onClick={handleDownloadReport}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all hover:scale-105"
          >
            <Download className="w-4 h-4" />
            <span>{downloadSuccess ? '✓ Spec Sheet Exported!' : 'Export Retrofit Spec Sheet'}</span>
          </button>
        </div>
      </div>

      {/* 4 Financial Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Net Investment Needed</div>
          <div className="text-2xl sm:text-3xl font-black text-white">
            ₹{(retrofitCalculations?.netInvestment || 45000).toLocaleString()}
          </div>
          <div className="text-[11px] text-urja-lime-400 mt-1 font-semibold">
            ₹{(retrofitCalculations?.totalSubsidy || 4000).toLocaleString()} BEE subsidy applied
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Annual Bill Savings</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-lime-400">
            ₹{(retrofitCalculations?.annualMoneySaved || 22000).toLocaleString()}
            <span className="text-xs font-semibold text-slate-400 ml-1">/yr</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            +₹{(retrofitCalculations?.monthlyMoneySaved || 1850).toLocaleString()} monthly cash savings
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">Payback Horizon</div>
          <div className="text-2xl sm:text-3xl font-black text-urja-cyan-300">
            {retrofitCalculations?.paybackYears || '2.1'}
            <span className="text-sm font-semibold text-slate-400 ml-1">Years</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Breakeven in {retrofitCalculations?.paybackMonths || 25} months
          </div>
        </div>

        <div className="cyber-card rounded-2xl p-4 shadow-cyber">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">10-Year Wealth Unlocked</div>
          <div className="text-2xl sm:text-3xl font-black text-amber-400">
            ₹{(retrofitCalculations?.tenYearNetReturn || 85000).toLocaleString()}
          </div>
          <div className="text-[11px] text-urja-lime-400 mt-1 font-semibold">
            {retrofitCalculations?.co2TonnesPerYear || '2.4'} Tonnes CO₂ offset
          </div>
        </div>

      </div>

      {/* Interactive Breakeven Curve Chart */}
      <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-urja-lime-400" />
              <span>Cumulative Financial Spend: Status Quo vs URJA Retrofit</span>
            </h3>
            <p className="text-xs text-slate-400">
              Notice the breakeven crossover point at Year {retrofitCalculations?.paybackYears || '2.1'}. Beyond this point, every single day is pure financial return.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-rose-400">
              <span className="w-3 h-1 bg-rose-500 rounded"></span> Inefficient Status Quo
            </span>
            <span className="flex items-center gap-1.5 text-urja-lime-400">
              <span className="w-3 h-1 bg-urja-lime-400 rounded"></span> URJA Retrofit Path
            </span>
          </div>
        </div>

        {/* SVG Breakeven Chart */}
        <div className="w-full h-52 bg-urja-navy-950 rounded-2xl p-4 relative overflow-hidden flex flex-col justify-end border border-urja-navy-750">
          <svg className="w-full h-full" viewBox="0 0 700 160" preserveAspectRatio="none">
            <line x1="40" y1="30" x2="680" y2="30" stroke="#162E48" strokeDasharray="3 3" />
            <line x1="40" y1="75" x2="680" y2="75" stroke="#162E48" strokeDasharray="3 3" />
            <line x1="40" y1="120" x2="680" y2="120" stroke="#162E48" strokeDasharray="3 3" />

            {/* Red Line Status Quo */}
            <path
              d="M40,140 L168,115 L296,90 L424,65 L552,40 L680,15"
              fill="none"
              stroke="#F43F5E"
              strokeWidth="3"
            />

            {/* Green Line Retrofit */}
            <path
              d="M40,95 L168,88 L296,81 L424,74 L552,67 L680,60"
              fill="none"
              stroke="#B7F34A"
              strokeWidth="3.5"
            />

            {/* Crossover circle */}
            <circle cx="296" cy="81" r="6" fill="#B7F34A" stroke="#07111F" strokeWidth="2" />
            <text x="310" y="80" fill="#B7F34A" fontSize="11" fontWeight="bold">
              Breakeven ({retrofitCalculations?.paybackYears || '2.1'} Yrs)
            </text>
          </svg>

          <div className="flex justify-between text-[10px] text-slate-500 pt-2 border-t border-urja-navy-800">
            <span>Year 0 (Today)</span>
            <span>Year 2</span>
            <span>Year 4</span>
            <span>Year 6</span>
            <span>Year 8</span>
            <span>Year 10</span>
          </div>
        </div>
      </div>

      {/* Upgrades Selection Grid */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-white">
            Customize Equipment Upgrades
          </h3>
          <p className="text-xs text-slate-400">
            Select or toggle options below to watch upfront investment and payback recalculate dynamically.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {RETROFIT_CATALOG.map((item) => {
            const isSelected = selectedRetrofits.includes(item.id);
            const Icon = iconsMap[item.icon] || TrendingUp;

            let unitsCount = 1;
            if (item.id === 'ac_upgrade') unitsCount = Math.max(1, (inventory?.airConditioners || []).length);
            if (item.id === 'bldc_fan') unitsCount = Math.max(1, (inventory?.fansCount || 5) - (inventory?.bldcFansCount || 0));
            if (item.id === 'led_conversion') unitsCount = Math.max(1, inventory?.cflTubesCount || 4);
            if (item.id === 'heatpump_geyser') unitsCount = Math.max(1, (inventory?.waterHeaters || []).length);

            const totalItemCost = item.avgUnitCost * unitsCount;
            const totalItemSavings = Math.round(item.annualEnergySavedKwh * unitsCount * (regionConfig?.baseTariff || 7.2));

            return (
              <div
                key={item.id}
                onClick={() => toggleRetrofit(item.id)}
                className={`p-5 rounded-3xl border cursor-pointer transition-all duration-200 ${
                  isSelected
                    ? 'cyber-card-lime shadow-glow-lime'
                    : 'cyber-card opacity-60 hover:opacity-100'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                      isSelected
                        ? 'bg-urja-lime-500 text-urja-navy-950 font-black shadow-glow-lime'
                        : 'bg-urja-navy-800 text-slate-400 border border-urja-navy-700'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-urja-lime-400">
                        {item.category} • {unitsCount} {unitsCount === 1 ? 'Unit' : 'Units'}
                      </span>
                      <h4 className="text-base font-bold text-white">
                        {item.title}
                      </h4>
                    </div>
                  </div>

                  <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-colors ${
                    isSelected
                      ? 'bg-urja-lime-500 border-urja-lime-500 text-urja-navy-950'
                      : 'border-urja-navy-700'
                  }`}>
                    {isSelected && <CheckCircle2 className="w-4 h-4" />}
                  </div>
                </div>

                <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                  {item.description}
                </p>

                <div className="mt-4 pt-3 border-t border-urja-navy-750 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Existing:</span>
                    <span className="font-semibold text-rose-400">{item.currentTech}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Upgraded:</span>
                    <span className="font-semibold text-urja-lime-400">{item.newTech}</span>
                  </div>
                </div>

                <div className="mt-3 p-3 rounded-2xl bg-urja-navy-900 border border-urja-navy-750 flex items-center justify-between text-xs font-semibold">
                  <div>
                    <span className="text-slate-400 text-[10px] block">Capital Outlay</span>
                    <span className="text-white font-bold">₹{totalItemCost.toLocaleString()}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400 text-[10px] block">Annual Savings</span>
                    <span className="text-urja-lime-400 font-black">+₹{totalItemSavings.toLocaleString()}/yr</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
