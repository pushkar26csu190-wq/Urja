import React from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  X, 
  Home, 
  LayoutDashboard, 
  Activity, 
  TrendingUp, 
  Clock, 
  Sun, 
  Moon,
  Calculator, 
  Compass, 
  Award, 
  Sliders, 
  Zap, 
  ChevronRight, 
  MapPin,
  Sparkles
} from 'lucide-react';

export const ThreeLineNavPanel = () => {
  const { 
    isNavPanelOpen, 
    setIsNavPanelOpen, 
    activeView, 
    setActiveView, 
    userProfile, 
    greenCoins, 
    ecoScore, 
    regionConfig,
    theme,
    toggleTheme
  } = useEnergy();

  if (!isNavPanelOpen) return null;

  const navigateTo = (viewId) => {
    setActiveView(viewId);
    setIsNavPanelOpen(false);
  };

  const sections = [
    {
      title: 'Main Hub',
      items: [
        { id: 'home', label: 'Home — Minimal Hero & Quick Launch', icon: Home, badge: 'Landing' },
        { id: 'dashboard', label: 'Overview — Executive IoT Dashboard', icon: LayoutDashboard, badge: 'Live Metrics' },
      ]
    },
    {
      title: 'The 4 Core AI Pillars',
      items: [
        { id: 'vampire', label: 'Pillar 1: Vampire Load & Diagnostics', icon: Activity, color: 'text-rose-400', badge: 'AI Pattern' },
        { id: 'retrofit', label: 'Pillar 2: Dynamic Retrofit ROI Simulator', icon: TrendingUp, color: 'text-urja-lime-400', badge: 'Payback Model' },
        { id: 'loadshift', label: 'Pillar 3: Smart Tier & Peak Load Shifting', icon: Clock, color: 'text-urja-cyan-400', badge: 'ToD Tariff' },
        { id: 'solar', label: 'Pillar 4: Urja-Mitra Solar & PM Surya Ghar', icon: Sun, color: 'text-amber-400', badge: 'Subsidy Matcher' },
      ]
    },
    {
      title: 'Interactive Clean-Tech Tools',
      items: [
        { id: 'calculator', label: 'Working Electricity Calculator', icon: Calculator, color: 'text-urja-lime-400', badge: 'Interactive' },
        { id: 'renewables', label: 'Renewable-Energy Explorer', icon: Compass, color: 'text-urja-cyan-400', badge: 'Clean Tech' },
      ]
    },
    {
      title: 'Community & Household',
      items: [
        { id: 'community', label: 'Community Eco-Leaderboard & Rewards', icon: Award, color: 'text-amber-400', badge: `${greenCoins} Coins` },
        { id: 'setup', label: 'Re-Calibrate Appliance Inventory', icon: Sliders, color: 'text-slate-300', badge: 'Wizard' },
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity animate-fadeIn"
        onClick={() => setIsNavPanelOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-urja-navy-900 dark:bg-urja-navy-900 border-l border-urja-navy-700 shadow-2xl flex flex-col">
          
          {/* Panel Header */}
          <div className="p-5 border-b border-urja-navy-750 flex items-center justify-between bg-urja-navy-950/40">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-urja-lime-500 to-urja-cyan-400 flex items-center justify-center text-urja-navy-950 font-black shadow-glow-lime">
                <Zap className="w-5 h-5 fill-current" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-lg text-white tracking-tight">URJA</span>
                  <span className="text-xs text-urja-lime-400 font-bold">ऊर्जा</span>
                </div>
                <p className="text-[10px] text-slate-400">Power Tomorrow. Smarter Today.</p>
              </div>
            </div>

            <button 
              onClick={() => setIsNavPanelOpen(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-urja-navy-800 transition-colors"
              aria-label="Close panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* ==================================================== */}
          {/* THEME TOGGLE OPTION: LIGHT MODE & DARK MODE IN PANEL */}
          {/* ==================================================== */}
          <div className="px-4 pt-4">
            <div className="p-3.5 rounded-2xl bg-urja-navy-800/90 border border-urja-navy-700 flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-urja-lime-400" />
                  <span>Interface Theme Mode</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-urja-cyan-400">
                  {theme === 'dark' ? 'Deep Navy' : 'Pastel Daylight'}
                </span>
              </div>

              {/* 2 Big Toggle Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => toggleTheme('dark')}
                  className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-extrabold transition-all ${
                    theme === 'dark'
                      ? 'bg-urja-navy-950 text-urja-cyan-300 border border-urja-cyan-400 shadow-glow-cyan'
                      : 'bg-urja-navy-900/60 text-slate-400 border border-urja-navy-700 hover:text-white'
                  }`}
                >
                  <Moon className="w-4 h-4 text-urja-cyan-300" />
                  <span>Dark Mode</span>
                </button>

                <button
                  onClick={() => toggleTheme('light')}
                  className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-extrabold transition-all ${
                    theme === 'light'
                      ? 'bg-white text-slate-900 border border-amber-400 shadow-md font-black'
                      : 'bg-urja-navy-900/60 text-slate-400 border border-urja-navy-700 hover:text-white'
                  }`}
                >
                  <Sun className="w-4 h-4 text-amber-500" />
                  <span>Light Mode</span>
                </button>
              </div>
            </div>
          </div>

          {/* User Quick Profile Chip */}
          <div className="p-3.5 mx-4 mt-3 rounded-2xl bg-urja-navy-800/60 border border-urja-navy-700 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-urja-cyan-400/20 text-urja-cyan-300 flex items-center justify-center font-bold">
                {userProfile?.name?.charAt(0) || 'U'}
              </div>
              <div>
                <div className="font-bold text-white">{userProfile?.name}</div>
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-urja-lime-400" />
                  <span>{userProfile?.city}</span>
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-[10px] text-slate-400">Eco-Score</div>
              <div className="font-black text-urja-lime-400 text-sm">{ecoScore}/100</div>
            </div>
          </div>

          {/* Navigation Menu Sections */}
          <div className="p-4 flex-1 overflow-y-auto space-y-5">
            {sections.map((sec, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 px-2">
                  {sec.title}
                </div>
                <div className="space-y-1">
                  {sec.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeView === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => navigateTo(item.id)}
                        className={`w-full flex items-center justify-between p-3 rounded-2xl text-xs font-semibold transition-all ${
                          isActive
                            ? 'bg-urja-navy-750 text-white border border-urja-cyan-400/60 shadow-glow-cyan'
                            : 'text-slate-300 hover:text-white hover:bg-urja-navy-800/80 border border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 ${item.color || (isActive ? 'text-urja-cyan-400' : 'text-slate-400')}`} />
                          <span className="text-left font-bold">{item.label}</span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {item.badge && (
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              isActive
                                ? 'bg-urja-cyan-400/20 text-urja-cyan-300'
                                : 'bg-urja-navy-700 text-slate-400'
                            }`}>
                              {item.badge}
                            </span>
                          )}
                          <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Footer Info */}
          <div className="p-4 border-t border-urja-navy-750 bg-urja-navy-950/60 text-center text-[11px] text-slate-400 space-y-1">
            <p className="font-semibold text-white">Mission: Smarter, Cleaner, More Accessible Energy</p>
            <p className="text-slate-500">Synced with {regionConfig?.discom?.split('(')[0] || 'DISCOM'}</p>
          </div>

        </div>
      </div>
    </div>
  );
};
