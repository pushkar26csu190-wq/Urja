import React from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { X, Bell, Zap, ArrowRight, CheckCircle2, ShieldAlert } from 'lucide-react';

export const NotificationDrawer = () => {
  const { 
    notifications, 
    setNotifications, 
    showNotificationDrawer, 
    setShowNotificationDrawer, 
    setActiveView 
  } = useEnergy();

  if (!showNotificationDrawer) return null;

  const dismissNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleAction = (type) => {
    setShowNotificationDrawer(false);
    if (type === 'peak_warning') {
      setActiveView('loadshift');
    } else if (type === 'vampire_detected') {
      setActiveView('vampire');
    } else if (type === 'solar_opportunity') {
      setActiveView('solar');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-urja-navy-950/70 backdrop-blur-sm transition-opacity"
        onClick={() => setShowNotificationDrawer(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-urja-navy-900 border-l border-urja-navy-700 shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-4 border-b border-urja-navy-750 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-urja-lime-500/10 border border-urja-lime-500/30 flex items-center justify-center text-urja-lime-400">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Grid & Energy Notifications</h3>
                <p className="text-xs text-slate-400">Real-time IoT & Tariff sync</p>
              </div>
            </div>
            <button 
              onClick={() => setShowNotificationDrawer(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-urja-navy-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Alert List */}
          <div className="p-4 flex-1 overflow-y-auto space-y-3">
            {!notifications || notifications.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-urja-lime-400 opacity-60" />
                <p className="text-sm">All clear! No critical energy alerts.</p>
              </div>
            ) : (
              notifications.map((notif) => {
                const isUrgent = notif.urgent;
                return (
                  <div 
                    key={notif.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isUrgent 
                        ? 'bg-rose-950/20 border-rose-500/40' 
                        : 'bg-urja-navy-800/80 border-urja-navy-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        {isUrgent ? (
                          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                        ) : (
                          <Zap className="w-4 h-4 text-urja-lime-400 shrink-0" />
                        )}
                        <span className={`text-xs font-bold ${isUrgent ? 'text-rose-300' : 'text-white'}`}>
                          {notif.title}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0">{notif.time}</span>
                    </div>

                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                      {notif.message}
                    </p>

                    <div className="mt-3 flex items-center justify-between pt-2 border-t border-urja-navy-750">
                      <button
                        onClick={() => handleAction(notif.type)}
                        className="flex items-center gap-1 text-xs font-bold text-urja-lime-400 hover:underline"
                      >
                        <span>Take Action</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => dismissNotification(notif.id)}
                        className="text-[11px] text-slate-400 hover:text-white"
                      >
                        Dismiss
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="p-3 border-t border-urja-navy-750 bg-urja-navy-950/50 text-center">
            <span className="text-[11px] text-slate-400">
              URJA AI monitors smart meter telemetry every 60 seconds
            </span>
          </div>

        </div>
      </div>
    </div>
  );
};
