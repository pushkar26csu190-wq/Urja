import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { 
  Compass, 
  Sun, 
  Wind, 
  BatteryCharging, 
  ArrowLeft, 
  Sparkles, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  Award,
  Layers
} from 'lucide-react';

export const RenewableExplorer = () => {
  const { userProfile, regionConfig, setActiveView, solarCalculations, triggerConfetti } = useEnergy();

  const [solarKw, setSolarKw] = useState(3.0);
  const [batteryKwh, setBatteryKwh] = useState(5.0);
  const [windKw, setWindKw] = useState(0.0);

  // Computed metrics
  const solarGenMonthly = Math.round(solarKw * 120);
  const windGenMonthly = Math.round(windKw * 85);
  const totalCleanGenMonthly = solarGenMonthly + windGenMonthly;

  const currentBillUnits = Math.round((userProfile?.monthlyBill || 5000) / (regionConfig?.baseTariff || 7.2));
  const selfSufficiencyPct = Math.min(100, Math.round((totalCleanGenMonthly / (currentBillUnits || 1)) * 100));

  const monthlyCashSaved = Math.round(Math.min(currentBillUnits, totalCleanGenMonthly) * (regionConfig?.baseTariff || 7.2));
  const co2AvoidedYearly = ((totalCleanGenMonthly * 12 * 0.82) / 1000).toFixed(2);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-urja-navy-750">
        <div>
          <button
            onClick={() => setActiveView('home')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-urja-cyan-400 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to URJA Home</span>
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400 shadow-glow-cyan">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-urja-cyan-400/20 text-urja-cyan-300 border border-urja-cyan-400/40">
                  Clean Tech Explorer
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Renewable-Energy Architecture Explorer
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Explore Solar PV, Residential Battery Storage (BESS), and Micro-Wind tailored to {userProfile?.city}.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => { setActiveView('solar'); triggerConfetti(); }}
          className="px-5 py-2.5 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-urja-navy-950 shadow-md shadow-amber-500/20 transition-all hover:scale-105"
        >
          Auto-Match PM Surya Ghar Subsidy →
        </button>
      </div>

      {/* 3 Tech Stack Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Tech 1: Rooftop Solar */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-3 shadow-glow-amber">
              <Sun className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Tier-1 Mono-PERC Solar PV</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Bi-facial solar cells with 22.8% efficiency. 1 kW generates ~120 units/mo in {regionConfig?.city || 'India'}.
            </p>
            <div className="mt-4 pt-3 border-t border-urja-navy-750 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Central Subsidy:</span>
                <span className="font-extrabold text-urja-lime-400">Up to ₹78,000</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Warranty:</span>
                <span className="font-bold text-white">25-Year Performance</span>
              </div>
            </div>
          </div>

          <div className="pt-3">
            <span className="text-[10px] text-slate-400 block mb-1">Simulate Capacity: {solarKw} kW</span>
            <input
              type="range"
              min="1"
              max="10"
              step="0.5"
              value={solarKw}
              onChange={(e) => setSolarKw(Number(e.target.value))}
              className="w-full accent-[#35C9FF] h-1.5 bg-urja-navy-750 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Tech 2: Residential Battery (BESS) */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-urja-cyan-400/10 border border-urja-cyan-400/30 flex items-center justify-center text-urja-cyan-400 mb-3 shadow-glow-cyan">
              <BatteryCharging className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">LiFePO4 Home Battery (BESS)</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Lithium Iron Phosphate storage. Stores daytime solar green energy for zero-tariff evening peak discharge.
            </p>
            <div className="mt-4 pt-3 border-t border-urja-navy-750 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Cycle Life:</span>
                <span className="font-extrabold text-urja-cyan-300">6,000+ Cycles (15 Yrs)</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Peak Protection:</span>
                <span className="font-bold text-white">100% Surge Shield</span>
              </div>
            </div>
          </div>

          <div className="pt-3">
            <span className="text-[10px] text-slate-400 block mb-1">Storage Size: {batteryKwh} kWh</span>
            <input
              type="range"
              min="0"
              max="15"
              step="2.5"
              value={batteryKwh}
              onChange={(e) => setBatteryKwh(Number(e.target.value))}
              className="w-full accent-[#35C9FF] h-1.5 bg-urja-navy-750 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Tech 3: Urban Micro-Wind */}
        <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-urja-lime-500/10 border border-urja-lime-500/30 flex items-center justify-center text-urja-lime-400 mb-3 shadow-glow-lime">
              <Wind className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Vertical-Axis Micro Wind</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Omnidirectional rooftop vertical-axis wind turbines. Whisper quiet operation (&lt;32 dB), generating 24/7 in gusty breezes.
            </p>
            <div className="mt-4 pt-3 border-t border-urja-navy-750 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Cut-in Wind Speed:</span>
                <span className="font-extrabold text-urja-lime-400">2.1 m/s Breeze</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Hybrid Compatibility:</span>
                <span className="font-bold text-white">Solar-Wind Synergy</span>
              </div>
            </div>
          </div>

          <div className="pt-3">
            <span className="text-[10px] text-slate-400 block mb-1">Wind Turbine: {windKw} kW</span>
            <input
              type="range"
              min="0"
              max="3"
              step="0.5"
              value={windKw}
              onChange={(e) => setWindKw(Number(e.target.value))}
              className="w-full accent-[#B7F34A] h-1.5 bg-urja-navy-750 rounded-lg cursor-pointer"
            />
          </div>
        </div>

      </div>

      {/* Simulated Hybrid Impact Matrix */}
      <div className="cyber-card rounded-3xl p-6 shadow-cyber space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-urja-lime-400" />
              <span>Simulated Clean Energy Independence Matrix</span>
            </h3>
            <p className="text-xs text-slate-400">
              Testing {solarKw} kW Solar + {batteryKwh} kWh Battery + {windKw} kW Wind for your {userProfile?.roomsCount}-room setup.
            </p>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">Grid Independence</div>
            <div className="text-2xl font-black text-urja-lime-400">{selfSufficiencyPct}%</div>
          </div>
        </div>

        <div className="w-full h-3 bg-urja-navy-800 rounded-full overflow-hidden flex">
          <div className="bg-urja-lime-400 h-full transition-all duration-500" style={{ width: `${selfSufficiencyPct}%` }} />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 text-xs">
          <div className="p-3 rounded-2xl bg-urja-navy-800 border border-urja-navy-700">
            <span className="text-[10px] text-slate-400 block">Monthly Clean Generation</span>
            <span className="text-lg font-black text-white">{totalCleanGenMonthly} kWh / mo</span>
          </div>
          <div className="p-3 rounded-2xl bg-urja-navy-800 border border-urja-navy-700">
            <span className="text-[10px] text-slate-400 block">Monthly Bill Avoidance</span>
            <span className="text-lg font-black text-urja-lime-400">+₹{monthlyCashSaved.toLocaleString()} / mo</span>
          </div>
          <div className="p-3 rounded-2xl bg-urja-navy-800 border border-urja-navy-700">
            <span className="text-[10px] text-slate-400 block">Annual Carbon Offset</span>
            <span className="text-lg font-black text-urja-cyan-300">{co2AvoidedYearly} Tonnes CO₂ / yr</span>
          </div>
        </div>
      </div>

    </div>
  );
};
