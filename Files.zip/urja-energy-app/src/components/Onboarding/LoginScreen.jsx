import React, { useState } from 'react';
import { useEnergy } from '../../context/EnergyContext';
import { Zap, ArrowRight, Sparkles } from 'lucide-react';

export const LoginScreen = () => {
  const { setIsLoggedIn, setActiveView, triggerConfetti } = useEnergy();
  const [email, setEmail] = useState('aarav.patel@greentech.in');
  const [password, setPassword] = useState('••••••••••••');

  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    triggerConfetti();
    setActiveView('setup');
  };

  const handleSkipDirectly = () => {
    setIsLoggedIn(true);
    setActiveView('home');
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full cyber-card rounded-3xl p-8 shadow-cyber space-y-6 text-center border-urja-navy-700">
        
        {/* Logo */}
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-urja-lime-500 to-urja-cyan-400 mx-auto flex items-center justify-center text-urja-navy-950 font-black shadow-glow-lime">
          <Zap className="w-8 h-8 fill-current" />
        </div>

        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-urja-lime-500/10 text-urja-lime-400 border border-urja-lime-500/30 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sanskrit: ऊर्जा (Clean Energy Force)</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">
            URJA AI Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Power Tomorrow. Smarter Today.
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Registered Account Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white text-xs font-semibold focus:outline-none focus:border-urja-lime-400"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Smart Meter Master Key / Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-urja-navy-700 bg-urja-navy-900 text-white text-xs font-semibold focus:outline-none focus:border-urja-lime-400"
              required
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl font-black text-xs bg-urja-lime-500 hover:bg-urja-lime-400 text-urja-navy-950 shadow-glow-lime transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Login & Start Household Setup Wizard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        <div className="pt-2 border-t border-urja-navy-750 flex items-center justify-between text-xs">
          <button
            onClick={handleSkipDirectly}
            className="text-slate-400 hover:text-urja-cyan-300 font-semibold transition-colors"
          >
            Explore Platform Directly →
          </button>
          <span className="text-[11px] text-slate-500">DISCOM Synced</span>
        </div>

      </div>
    </div>
  );
};
